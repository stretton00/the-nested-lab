# VCF Automation 9.1 blueprint reference: downloads

Companion files for "Every resource in the VCF Automation 9.1 blueprint designer: the complete guide".
Captured on 1 Oct 2026 from a VCF 9.1.0 platform (Supervisor on Kubernetes 1.32.9, VM Operator v1alpha5,
VKS ClusterClass builtin-generic-v3.6.0, NSX VPCs).

- tested-blueprints/  The five blueprints the guide was tested with, as they ran. Names such as f06,
                      nested-pod, vpc-student05, default--f06, domain-c9 and vsan-default-storage-policy
                      belong to our platform: replace them with yours. test1b-nat.yaml points at the VPC
                      that test1-vpc.yaml created and at the address it allocated.
- schemas/base-resource-types.json
                      The five blueprint resource types (CCI.Supervisor.Namespace, CCI.Supervisor.Resource,
                      CCI.VPC, CCI.VPC.Configuration, Util.PasswordEntry) as VCF Automation's API returns them
                      (blueprint.cci.vmware.com/v1alpha1 BlueprintResourceType).
- schemas/palette.json
                      The designer's palette map: each item's base type, apiVersion and kind.
- schemas/designer/   The fifteen palette schemas the designer ships. Where they disagree with what the
                      platform accepts, the guide's tables follow the platform.
- field-tables/       The guide's "every field the platform accepts" tables, as Markdown, generated from the
                      Supervisor's CRDs, its core OpenAPI, VCF Automation's VPC API and the ClusterClass.

Lab work, offered as is; check field names against your own platform's versions.

| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.advanced` | object |  |  | Advanced describes a set of optional, advanced VM configuration options. |
| `spec.advanced.bootDiskCapacity` | int or string |  |  | BootDiskCapacity is the capacity of the VM's boot disk -- the first disk from the VirtualMachineImage from which the VM was deployed. |
| `spec.advanced.changeBlockTracking` | boolean |  |  | ChangeBlockTracking is a flag that enables incremental backup support for this VM, a feature utilized by external backup systems such as VMware Data Recovery. |
| `spec.advanced.defaultVolumeProvisioningMode` | string |  | `Thin`, `Thick`, `ThickEagerZero` | DefaultVolumeProvisioningMode specifies the default provisioning mode for persistent volumes managed by this VM. |
| `spec.affinity` | object |  |  | Affinity describes the VM's scheduling constraints. |
| `spec.affinity.vmAffinity` | object |  |  | VMAffinity describes affinity scheduling rules related to other VMs. |
| `spec.affinity.vmAffinity.preferredDuringSchedulingPreferredDuringExecution` | array of object |  |  | PreferredDuringSchedulingPreferredDuringExecution describes affinity requirements that should be met, but the VM can still be scheduled if the requirement cannot be satisfied. |
| `spec.affinity.vmAffinity.preferredDuringSchedulingPreferredDuringExecution[].labelSelector` | object |  |  | LabelSelector is a label query over a set of VMs. When omitted, this term matches with no VMs. |
| `spec.affinity.vmAffinity.preferredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions` | array of object |  |  | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.affinity.vmAffinity.preferredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions[].key` | string | yes |  | key is the label key that the selector applies to. |
| `spec.affinity.vmAffinity.preferredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions[].operator` | string | yes |  | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.affinity.vmAffinity.preferredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions[].values` | array of string |  |  | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.affinity.vmAffinity.preferredDuringSchedulingPreferredDuringExecution[].labelSelector.matchLabels` | object |  |  | matchLabels is a map of {key,value} pairs. |
| `spec.affinity.vmAffinity.preferredDuringSchedulingPreferredDuringExecution[].topologyKey` | string | yes |  | TopologyKey describes where this VM should be co-located (affinity) or not co-located (anti-affinity). |
| `spec.affinity.vmAffinity.requiredDuringSchedulingPreferredDuringExecution` | array of object |  |  | RequiredDuringSchedulingPreferredDuringExecution describes affinity requirements that must be met or the VM will not be scheduled. |
| `spec.affinity.vmAffinity.requiredDuringSchedulingPreferredDuringExecution[].labelSelector` | object |  |  | LabelSelector is a label query over a set of VMs. When omitted, this term matches with no VMs. |
| `spec.affinity.vmAffinity.requiredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions` | array of object |  |  | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.affinity.vmAffinity.requiredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions[].key` | string | yes |  | key is the label key that the selector applies to. |
| `spec.affinity.vmAffinity.requiredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions[].operator` | string | yes |  | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.affinity.vmAffinity.requiredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions[].values` | array of string |  |  | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.affinity.vmAffinity.requiredDuringSchedulingPreferredDuringExecution[].labelSelector.matchLabels` | object |  |  | matchLabels is a map of {key,value} pairs. |
| `spec.affinity.vmAffinity.requiredDuringSchedulingPreferredDuringExecution[].topologyKey` | string | yes |  | TopologyKey describes where this VM should be co-located (affinity) or not co-located (anti-affinity). |
| `spec.affinity.vmAntiAffinity` | object |  |  | VMAntiAffinity describes anti-affinity scheduling rules related to other VMs. |
| `spec.affinity.vmAntiAffinity.preferredDuringSchedulingPreferredDuringExecution` | array of object |  |  | PreferredDuringSchedulingPreferredDuringExecution describes anti-affinity requirements that should be met, but the VM can still be scheduled if the requirement cannot be satisfied. |
| `spec.affinity.vmAntiAffinity.preferredDuringSchedulingPreferredDuringExecution[].labelSelector` | object |  |  | LabelSelector is a label query over a set of VMs. When omitted, this term matches with no VMs. |
| `spec.affinity.vmAntiAffinity.preferredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions` | array of object |  |  | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.affinity.vmAntiAffinity.preferredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions[].key` | string | yes |  | key is the label key that the selector applies to. |
| `spec.affinity.vmAntiAffinity.preferredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions[].operator` | string | yes |  | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.affinity.vmAntiAffinity.preferredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions[].values` | array of string |  |  | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.affinity.vmAntiAffinity.preferredDuringSchedulingPreferredDuringExecution[].labelSelector.matchLabels` | object |  |  | matchLabels is a map of {key,value} pairs. |
| `spec.affinity.vmAntiAffinity.preferredDuringSchedulingPreferredDuringExecution[].topologyKey` | string | yes |  | TopologyKey describes where this VM should be co-located (affinity) or not co-located (anti-affinity). |
| `spec.affinity.vmAntiAffinity.requiredDuringSchedulingPreferredDuringExecution` | array of object |  |  | RequiredDuringSchedulingPreferredDuringExecution describes anti-affinity requirements that must be met or the VM will not be scheduled. |
| `spec.affinity.vmAntiAffinity.requiredDuringSchedulingPreferredDuringExecution[].labelSelector` | object |  |  | LabelSelector is a label query over a set of VMs. When omitted, this term matches with no VMs. |
| `spec.affinity.vmAntiAffinity.requiredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions` | array of object |  |  | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.affinity.vmAntiAffinity.requiredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions[].key` | string | yes |  | key is the label key that the selector applies to. |
| `spec.affinity.vmAntiAffinity.requiredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions[].operator` | string | yes |  | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.affinity.vmAntiAffinity.requiredDuringSchedulingPreferredDuringExecution[].labelSelector.matchExpressions[].values` | array of string |  |  | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.affinity.vmAntiAffinity.requiredDuringSchedulingPreferredDuringExecution[].labelSelector.matchLabels` | object |  |  | matchLabels is a map of {key,value} pairs. |
| `spec.affinity.vmAntiAffinity.requiredDuringSchedulingPreferredDuringExecution[].topologyKey` | string | yes |  | TopologyKey describes where this VM should be co-located (affinity) or not co-located (anti-affinity). |
| `spec.biosUUID` | string |  |  | BiosUUID describes the desired BIOS UUID for a VM. If omitted, this field defaults to a random UUID. |
| `spec.bootOptions` | object |  |  | BootOptions describes the settings that control the boot behavior of the virtual machine. These settings take effect during the next power-on of the virtual machine. |
| `spec.bootOptions.bootDelay` | string |  |  | BootDelay is the delay before starting the boot sequence. The boot delay specifies a time interval between virtual machine power on or restart and the beginning of the boot sequence. |
| `spec.bootOptions.bootOrder` | array of object |  |  | BootOrder represents the boot order of the virtual machine. After list is exhausted, default BIOS boot device algorithm is used for booting. |
| `spec.bootOptions.bootOrder[].name` | string |  |  | Name represents the name of the bootable device. It is required for Disk and Network device types, while ignored for CDRom device types. |
| `spec.bootOptions.bootOrder[].type` | string | yes | `Disk`, `Network`, `CDRom` | Type represents the type of bootable device. The available device types are: - Disk - Network - CDRom |
| `spec.bootOptions.bootRetry` | string |  | default `Disabled` | BootRetry specifies whether a virtual machine that fails to boot will try again. |
| `spec.bootOptions.bootRetryDelay` | string |  |  | BootRetryDelay specifies a time interval between virtual machine boot failure and the subsequent attempt to boot again. |
| `spec.bootOptions.efiSecureBoot` | string |  | `Enabled`, `Disabled`; default `Disabled` | EFISecureBoot specifies whether the virtual machine's firmware will perform signature checks of any EFI images loaded during startup. |
| `spec.bootOptions.firmware` | string |  | `bios`, `efi` | Firmware represents the firmware for the virtual machine to use. Any update to this value after the virtual machine has already been created will be ignored. |
| `spec.bootOptions.networkBootProtocol` | string |  | `IP4`, `IP6`; default `IP4` | NetworkBootProtocol is the protocol to attempt during PXE network boot or NetBoot. The available protocols are: - IP4 -- PXE (or Apple NetBoot) over IPv4. |
| `spec.bootstrap` | object |  |  | Bootstrap describes the desired state of the guest's bootstrap configuration. If omitted, a default bootstrap method may be selected based on the guest OS identifier. |
| `spec.bootstrap.cloudInit` | object |  |  | CloudInit may be used to bootstrap Linux guests with Cloud-Init or Windows guests that support Cloudbase-Init. |
| `spec.bootstrap.cloudInit.cloudConfig` | object |  |  | CloudConfig describes a subset of a Cloud-Init CloudConfig, used to bootstrap the VM. |
| `spec.bootstrap.cloudInit.cloudConfig.defaultUserEnabled` | boolean |  |  | DefaultUserEnabled may be set to true to ensure even if the Users field is not empty, the default user is still created on systems that have one defined. |
| `spec.bootstrap.cloudInit.cloudConfig.runcmd` | any |  |  | RunCmd allows running one or more commands on the guest. The entries in this list can adhere to two, different formats: Format 1 -- a string that contains the command and its arguments, ex. |
| `spec.bootstrap.cloudInit.cloudConfig.ssh_pwauth` | boolean |  |  | SSHPwdAuth sets whether or not to accept password authentication. In order for this config to be applied, SSH may need to be restarted. |
| `spec.bootstrap.cloudInit.cloudConfig.timezone` | string |  |  | Timezone describes the timezone represented in /usr/share/zoneinfo. |
| `spec.bootstrap.cloudInit.cloudConfig.users` | array of object |  |  | Users allows adding/configuring one or more users on the guest. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].create_groups` | boolean |  |  | CreateGroups is a flag that may be set to false to disable creation of specified user groups. Defaults to true when Name is not "default". |
| `spec.bootstrap.cloudInit.cloudConfig.users[].expiredate` | string |  |  | ExpireData is the date on which the user's account will be disabled. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].gecos` | string |  |  | Gecos is an optional comment about the user, usually a comma-separated string of the user's real name and contact information. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].groups` | array of string |  |  | Groups is an optional list of groups to add to the user. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].hashed_passwd` | object |  |  | HashedPasswd is a hash of the user's password that will be applied even if the specified user already exists. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].hashed_passwd.key` | string | yes |  | Key is the key in the secret that specifies the requested data. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].hashed_passwd.name` | string | yes |  | Name is the name of the secret. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].homedir` | string |  |  | Homedir is the optional home directory for the user. Defaults to "/home/<username>" when Name is not "default". |
| `spec.bootstrap.cloudInit.cloudConfig.users[].inactive` | integer |  |  | Inactive optionally represents the number of days until the user is disabled. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].lock_passwd` | boolean |  |  | LockPasswd disables password login. Defaults to true when Name is not "default". |
| `spec.bootstrap.cloudInit.cloudConfig.users[].name` | string | yes |  | Name is the user's login name. When set to "default", all other fields from this User must be nil. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].no_create_home` | boolean |  |  | NoCreateHome prevents the creation of the home directory. Defaults to false when Name is not "default". |
| `spec.bootstrap.cloudInit.cloudConfig.users[].no_log_init` | boolean |  |  | NoLogInit prevents the initialization of lastlog and faillog for the user. Defaults to false when Name is not "default". |
| `spec.bootstrap.cloudInit.cloudConfig.users[].no_user_group` | boolean |  |  | NoUserGroup prevents the creation of the group named after the user. Defaults to false when Name is not "default". |
| `spec.bootstrap.cloudInit.cloudConfig.users[].passwd` | object |  |  | Passwd is a hash of the user's password that will be applied only to a newly created user. To apply a new, hashed password to an existing user please use HashedPasswd instead. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].passwd.key` | string | yes |  | Key is the key in the secret that specifies the requested data. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].passwd.name` | string | yes |  | Name is the name of the secret. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].primary_group` | string |  |  | PrimaryGroup is the primary group for the user. Defaults to the value of the Name field when it is not "default". |
| `spec.bootstrap.cloudInit.cloudConfig.users[].selinux_user` | string |  |  | SELinuxUser is the SELinux user for the user's login. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].shell` | string |  |  | Shell is the path to the user's login shell. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].snapuser` | string |  |  | SnapUser specifies an e-mail address to create the user as a Snappy user through "snap create-user". |
| `spec.bootstrap.cloudInit.cloudConfig.users[].ssh_authorized_keys` | array of string |  |  | SSHAuthorizedKeys is a list of SSH keys to add to the user's authorized keys file. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].ssh_import_id` | array of string |  |  | SSHImportID is a list of SSH IDs to import for the user. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].ssh_redirect_user` | boolean |  |  | SSHRedirectUser may be set to true to disable SSH logins for this user. Any SSH login as this user will timeout with a message to login instead as the default user. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].sudo` | string |  |  | Sudo is a sudo rule to apply to the user. When omitted, no sudo rules will be applied to the user. |
| `spec.bootstrap.cloudInit.cloudConfig.users[].system` | boolean |  |  | System is an optional flag that indicates the user should be created as a system user with no home directory. Defaults to false when Name is not "default". |
| `spec.bootstrap.cloudInit.cloudConfig.users[].uid` | integer |  |  | UID is the user's ID. When omitted the guest will default to the next available number. |
| `spec.bootstrap.cloudInit.cloudConfig.write_files` | array of object |  |  | WriteFiles allows adding files to the guest file system. |
| `spec.bootstrap.cloudInit.cloudConfig.write_files[].append` | boolean |  |  | Append specifies whether or not to append the content to an existing file if the file specified by Path already exists. |
| `spec.bootstrap.cloudInit.cloudConfig.write_files[].content` | any |  |  | Content is the optional content to write to the provided Path. When omitted an empty file will be created or existing file will be modified. |
| `spec.bootstrap.cloudInit.cloudConfig.write_files[].defer` | boolean |  |  | Defer indicates to defer writing the file until Cloud-Init's "final" stage, after users are created and packages are installed. |
| `spec.bootstrap.cloudInit.cloudConfig.write_files[].encoding` | string |  | `b64`, `base64`, `gz`, `gzip`, `gz+b64`, `gz+base64`, `gzip+b64`, `gzip+base64`, `text/plain`; default `text/plain` | Encoding is an optional encoding type of the content. |
| `spec.bootstrap.cloudInit.cloudConfig.write_files[].owner` | string |  | default `root:root` | Owner is an optional "owner:group" to chown the file. |
| `spec.bootstrap.cloudInit.cloudConfig.write_files[].path` | string | yes |  | Path is the path of the file to which the content is decoded and written. |
| `spec.bootstrap.cloudInit.cloudConfig.write_files[].permissions` | string |  | default `0644` | Permissions an optional set of file permissions to set. "0###". When omitted the guest will default this value to "0644". |
| `spec.bootstrap.cloudInit.instanceID` | string |  |  | InstanceID is the cloud-init metadata instance ID. If omitted, this field defaults to the VM's BiosUUID. |
| `spec.bootstrap.cloudInit.rawCloudConfig` | object |  |  | RawCloudConfig describes a key in a Secret resource that contains the CloudConfig data used to bootstrap the VM. |
| `spec.bootstrap.cloudInit.rawCloudConfig.key` | string | yes |  | Key is the key in the secret that specifies the requested data. |
| `spec.bootstrap.cloudInit.rawCloudConfig.name` | string | yes |  | Name is the name of the secret. |
| `spec.bootstrap.cloudInit.sshAuthorizedKeys` | array of string |  |  | SSHAuthorizedKeys is a list of public keys that CloudInit will apply to the guest's default user. |
| `spec.bootstrap.cloudInit.useGlobalNameserversAsDefault` | boolean |  |  | UseGlobalNameserversAsDefault will use the global nameservers specified in the NetworkSpec as the per-interface nameservers when the per-interface nameservers is not provided. |
| `spec.bootstrap.cloudInit.useGlobalSearchDomainsAsDefault` | boolean |  |  | UseGlobalSearchDomainsAsDefault will use the global search domains specified in the NetworkSpec as the per-interface search domains when the per-interface search domains is not provided. |
| `spec.bootstrap.cloudInit.waitOnNetwork4` | boolean |  |  | WaitOnNetwork4 indicates whether the cloud-init datasource should wait for an IPv4 address to be available before writing the instance-data. |
| `spec.bootstrap.cloudInit.waitOnNetwork6` | boolean |  |  | WaitOnNetwork6 indicates whether the cloud-init datasource should wait for an IPv6 address to be available before writing the instance-data. |
| `spec.bootstrap.linuxPrep` | object |  |  | LinuxPrep may be used to bootstrap Linux guests. The guest's networking stack is configured by Guest OS Customization (GOSC). |
| `spec.bootstrap.linuxPrep.customizeAtNextPowerOn` | boolean |  |  | CustomizeAtNextPowerOn describes when customization is performed on the VM. When set to false, the VM will not be customized at the next power on. |
| `spec.bootstrap.linuxPrep.expirePasswordAfterNextLogin` | boolean |  |  | ExpirePasswordAfterNextLogin indicates whether or not the root account is required to change their password after the next login. |
| `spec.bootstrap.linuxPrep.hardwareClockIsUTC` | boolean |  |  | HardwareClockIsUTC specifies whether the hardware clock is in UTC or local time. |
| `spec.bootstrap.linuxPrep.password` | object |  |  | Password is the new root password for the machine. When not explicitly specified, the Key field for the selector defaults to `password`. |
| `spec.bootstrap.linuxPrep.password.key` | string |  | default `password` | Key is the key in the secret that specifies the requested data. |
| `spec.bootstrap.linuxPrep.password.name` | string | yes |  | Name is the name of the secret. |
| `spec.bootstrap.linuxPrep.scriptText` | object |  |  | ScriptText is the script to run before and after customization. Please see https://knowledge.broadcom.com/external/article?legacyId=1026614 for script examples. |
| `spec.bootstrap.linuxPrep.scriptText.from` | object |  |  | From is specified to reference a value from a Secret resource. |
| `spec.bootstrap.linuxPrep.scriptText.from.key` | string | yes |  | Key is the key in the secret that specifies the requested data. |
| `spec.bootstrap.linuxPrep.scriptText.from.name` | string | yes |  | Name is the name of the secret. |
| `spec.bootstrap.linuxPrep.scriptText.value` | string |  |  | Value is used to directly specify a value. |
| `spec.bootstrap.linuxPrep.timeZone` | string |  |  | TimeZone is a case-sensitive timezone, such as Europe/Sofia. Valid values are based on the tz (timezone) database used by Linux and other Unix systems. |
| `spec.bootstrap.sysprep` | object |  |  | Sysprep may be used to bootstrap Windows guests. The guest's networking stack is configured by Guest OS Customization (GOSC). |
| `spec.bootstrap.sysprep.customizeAtNextPowerOn` | boolean |  |  | CustomizeAtNextPowerOn describes when customization is performed on the VM. When set to false, the VM will not be customized at the next power on. |
| `spec.bootstrap.sysprep.rawSysprep` | object |  |  | RawSysprep describes a key in a Secret resource that contains an XML string of the Sysprep text used to bootstrap the VM. |
| `spec.bootstrap.sysprep.rawSysprep.key` | string | yes |  | Key is the key in the secret that specifies the requested data. |
| `spec.bootstrap.sysprep.rawSysprep.name` | string | yes |  | Name is the name of the secret. |
| `spec.bootstrap.sysprep.sysprep` | object |  |  | Sysprep is an object representation of a Windows sysprep.xml answer file. This field encloses all the individual keys listed in a sysprep.xml file. |
| `spec.bootstrap.sysprep.sysprep.expirePasswordAfterNextLogin` | boolean |  |  | ExpirePasswordAfterNextLogin indicates whether or not the local Administrators group accounts are required to change their password after the next login. |
| `spec.bootstrap.sysprep.sysprep.guiRunOnce` | object |  |  | GUIRunOnce is a representation of the Sysprep GuiRunOnce key. |
| `spec.bootstrap.sysprep.sysprep.guiRunOnce.commands` | array of string |  |  | Commands is a list of commands to run at first user logon, after guest customization. |
| `spec.bootstrap.sysprep.sysprep.guiUnattended` | object |  |  | GUIUnattended is a representation of the Sysprep GUIUnattended key. |
| `spec.bootstrap.sysprep.sysprep.guiUnattended.autoLogon` | boolean |  |  | AutoLogon determine whether the machine automatically logs on as Administrator. |
| `spec.bootstrap.sysprep.sysprep.guiUnattended.autoLogonCount` | integer |  |  | AutoLogonCount specifies the number of times the machine should automatically log on as Administrator. |
| `spec.bootstrap.sysprep.sysprep.guiUnattended.password` | object |  |  | Password is the new administrator password for the machine. To specify that the password should be set to blank (that is, no password), set the password value to NULL. |
| `spec.bootstrap.sysprep.sysprep.guiUnattended.password.key` | string | yes | default `password` | Key is the key in the secret that specifies the requested data. |
| `spec.bootstrap.sysprep.sysprep.guiUnattended.password.name` | string | yes |  | Name is the name of the secret. |
| `spec.bootstrap.sysprep.sysprep.guiUnattended.timeZone` | integer |  | default `85` | TimeZone is the time zone index for the virtual machine.ly/3Rzv8oL. Defaults to UTC. |
| `spec.bootstrap.sysprep.sysprep.identification` | object |  |  | Identification is a representation of the Sysprep Identification key. |
| `spec.bootstrap.sysprep.sysprep.identification.domainAdmin` | string |  |  | DomainAdmin is the domain user account used for authentication if the virtual machine is joining a domain. |
| `spec.bootstrap.sysprep.sysprep.identification.domainAdminPassword` | object |  |  | DomainAdminPassword is the password for the domain user account used for authentication if the virtual machine is joining a domain. |
| `spec.bootstrap.sysprep.sysprep.identification.domainAdminPassword.key` | string | yes | default `domain_admin_password` | Key is the key in the secret that specifies the requested data. |
| `spec.bootstrap.sysprep.sysprep.identification.domainAdminPassword.name` | string | yes |  | Name is the name of the secret. |
| `spec.bootstrap.sysprep.sysprep.identification.domainOU` | string |  |  | DomainOU is the MachineObjectOU which specifies the full LDAP path name of the OU to which the computer belongs. |
| `spec.bootstrap.sysprep.sysprep.identification.joinWorkgroup` | string |  |  | JoinWorkgroup is the workgroup that the virtual machine should join. |
| `spec.bootstrap.sysprep.sysprep.licenseFilePrintData` | object |  |  | LicenseFilePrintData is a representation of the Sysprep LicenseFilePrintData key. |
| `spec.bootstrap.sysprep.sysprep.licenseFilePrintData.autoMode` | string | yes | `perSeat`, `perServer` | AutoMode specifies the server licensing mode. |
| `spec.bootstrap.sysprep.sysprep.licenseFilePrintData.autoUsers` | integer |  |  | AutoUsers indicates the number of client licenses purchased for the VirtualCenter server being installed. |
| `spec.bootstrap.sysprep.sysprep.scriptText` | object |  |  | ScriptText describes the script to run before and after customization. The script must be a Windows batch file. |
| `spec.bootstrap.sysprep.sysprep.scriptText.from` | object |  |  | From is specified to reference a value from a Secret resource. |
| `spec.bootstrap.sysprep.sysprep.scriptText.from.key` | string | yes |  | Key is the key in the secret that specifies the requested data. |
| `spec.bootstrap.sysprep.sysprep.scriptText.from.name` | string | yes |  | Name is the name of the secret. |
| `spec.bootstrap.sysprep.sysprep.scriptText.value` | string |  |  | Value is used to directly specify a value. |
| `spec.bootstrap.sysprep.sysprep.userData` | object | yes |  | UserData is a representation of the Sysprep UserData key. |
| `spec.bootstrap.sysprep.sysprep.userData.fullName` | string | yes |  | FullName is the user's full name. |
| `spec.bootstrap.sysprep.sysprep.userData.orgName` | string | yes |  | OrgName is the name of the user's organization. |
| `spec.bootstrap.sysprep.sysprep.userData.productID` | object |  |  | ProductID is a valid serial number. When not explicitly specified, the Key field for the selector defaults to `domain_admin_password`. |
| `spec.bootstrap.sysprep.sysprep.userData.productID.key` | string | yes | default `product_id` | Key is the key in the secret that specifies the requested data. |
| `spec.bootstrap.sysprep.sysprep.userData.productID.name` | string | yes |  | Name is the name of the secret. |
| `spec.bootstrap.vAppConfig` | object |  |  | VAppConfig may be used to bootstrap guests that rely on vApp properties (how VMware surfaces OVF properties on guests) to transport data into the guest. |
| `spec.bootstrap.vAppConfig.properties` | array of object |  |  | Properties is a list of vApp/OVF property key/value pairs. |
| `spec.bootstrap.vAppConfig.properties[].key` | string | yes |  | Key is the key part of the key/value pair. |
| `spec.bootstrap.vAppConfig.properties[].value` | object |  |  | Value is the optional value part of the key/value pair. |
| `spec.bootstrap.vAppConfig.properties[].value.from` | object |  |  | From is specified to reference a value from a Secret resource. |
| `spec.bootstrap.vAppConfig.properties[].value.from.key` | string | yes |  | Key is the key in the secret that specifies the requested data. |
| `spec.bootstrap.vAppConfig.properties[].value.from.name` | string | yes |  | Name is the name of the secret. |
| `spec.bootstrap.vAppConfig.properties[].value.value` | string |  |  | Value is used to directly specify a value. |
| `spec.bootstrap.vAppConfig.rawProperties` | string |  |  | RawProperties is the name of a Secret resource in the same Namespace as this VM where each key/value pair from the Secret is used as a vApp key/value pair. |
| `spec.class` | object |  |  | Class describes the VirtualMachineClassInstance resource that is referenced by this virtual machine. |
| `spec.class.apiVersion` | string | yes |  | APIVersion defines the versioned schema of this representation of an object. |
| `spec.class.kind` | string | yes |  | Kind is a string value representing the REST resource this object represents. Servers may infer this from the endpoint the client submits requests to. |
| `spec.class.name` | string | yes |  | Name refers to a unique resource in the current namespace. |
| `spec.className` | string |  |  | ClassName describes the name of the VirtualMachineClass resource used to deploy this VM. |
| `spec.crypto` | object |  |  | Crypto describes the desired encryption state of the VirtualMachine. |
| `spec.crypto.encryptionClassName` | string |  |  | EncryptionClassName describes the name of the EncryptionClass resource used to encrypt this VM. |
| `spec.crypto.useDefaultKeyProvider` | boolean |  | default `true` | UseDefaultKeyProvider describes the desired behavior for when an explicit EncryptionClass is not provided. |
| `spec.crypto.vTPMMode` | string |  | `Clone`, `New`; default `New` | VTPMMode describes the desired behavior when deploying a VirtualMachine using a VirtualMachine-backed image which created from an encrypted VirtualMachine with a vTPM. |
| `spec.currentSnapshotName` | string |  |  | CurrentSnapshotName represents the desired snapshot that the VM should point to. This field can be specified to revert the VM to a given snapshot. |
| `spec.groupName` | string |  |  | GroupName indicates the name of the VirtualMachineGroup to which this VM belongs. VMs that belong to a group do not drive their own placement, rather that is handled by the group. |
| `spec.guestID` | string |  |  | GuestID describes the desired guest operating system identifier for a VM. The logic that determines the guest ID is as follows: If this field is set, then its value is used. |
| `spec.hardware` | object |  |  | Hardware describes the VM's desired hardware. |
| `spec.hardware.cdrom` | array of object |  |  | Cdrom describes the desired state of the VM's CD-ROM devices. Each CD-ROM device requires a reference to an ISO-type VirtualMachineImage or ClusterVirtualMachineImage resource as backing. |
| `spec.hardware.cdrom[].allowGuestControl` | boolean |  | default `true` | AllowGuestControl describes whether or not a web console connection may be used to connect/disconnect the CD-ROM device. |
| `spec.hardware.cdrom[].connected` | boolean |  | default `true` | Connected describes the desired connection state of the CD-ROM device. When true, the CD-ROM device is added and connected to the VM. |
| `spec.hardware.cdrom[].controllerBusNumber` | integer |  |  | ControllerBusNumber describes the bus number of the controller to which this CD-ROM should be attached. |
| `spec.hardware.cdrom[].controllerType` | string |  |  | ControllerType describes the type of the controller to which this CD-ROM should be attached. |
| `spec.hardware.cdrom[].image` | object | yes |  | Image describes the reference to an ISO type VirtualMachineImage or ClusterVirtualMachineImage resource used as the backing for the CD-ROM. |
| `spec.hardware.cdrom[].image.kind` | string | yes |  | Kind describes the type of image, either a namespace-scoped VirtualMachineImage or cluster-scoped ClusterVirtualMachineImage. |
| `spec.hardware.cdrom[].image.name` | string | yes |  | Name refers to the name of a VirtualMachineImage resource in the same namespace as this VM or a cluster-scoped ClusterVirtualMachineImage. |
| `spec.hardware.cdrom[].name` | string | yes |  | Name consists of at least two lowercase letters or digits of this CD-ROM. It must be unique among all CD-ROM devices attached to the VM. |
| `spec.hardware.cdrom[].unitNumber` | integer |  |  | UnitNumber describes the desired unit number for attaching the CD-ROM to a storage controller. When omitted, the next available unit number of the selected controller is used. |
| `spec.hardware.ideControllers` | array of object |  |  | IDEControllers describes the desired list of IDE controllers for the VM. Defaults to two IDE controllers, with bus 0 and bus 1. |
| `spec.hardware.ideControllers[].busNumber` | integer | yes |  | BusNumber describes the desired bus number of the controller. |
| `spec.hardware.nvmeControllers` | array of object |  |  | NVMEControllers describes the desired list of NVME controllers for the VM. |
| `spec.hardware.nvmeControllers[].busNumber` | integer | yes |  | BusNumber describes the desired bus number of the controller. |
| `spec.hardware.nvmeControllers[].sharingMode` | string |  | `None`, `Physical`; default `None` | SharingMode describes the sharing mode for the controller. Defaults to None. |
| `spec.hardware.sataControllers` | array of object |  |  | SATAControllers describes the desired list of SATA controllers for the VM. |
| `spec.hardware.sataControllers[].busNumber` | integer | yes |  | BusNumber describes the desired bus number of the controller. |
| `spec.hardware.scsiControllers` | array of object |  |  | SCSIControllers describes the desired list of SCSI controllers for the VM. |
| `spec.hardware.scsiControllers[].busNumber` | integer | yes |  | BusNumber describes the desired bus number of the controller. |
| `spec.hardware.scsiControllers[].sharingMode` | string |  | `None`, `Physical`, `Virtual`; default `None` | SharingMode describes the sharing mode for the controller. Defaults to None. |
| `spec.hardware.scsiControllers[].type` | string |  | `ParaVirtual`, `BusLogic`, `LsiLogic`, `LsiLogicSAS`; default `ParaVirtual` | Type describes the desired type of SCSI controller. Defaults to ParaVirtual. |
| `spec.image` | object |  |  | Image describes the reference to the VirtualMachineImage or ClusterVirtualMachineImage resource used to deploy this VM.imageName, the value of spec.image.name MUST be a Kubernetes object ... |
| `spec.image.kind` | string | yes |  | Kind describes the type of image, either a namespace-scoped VirtualMachineImage or cluster-scoped ClusterVirtualMachineImage. |
| `spec.image.name` | string | yes |  | Name refers to the name of a VirtualMachineImage resource in the same namespace as this VM or a cluster-scoped ClusterVirtualMachineImage. |
| `spec.imageName` | string |  |  | ImageName describes the name of the image resource used to deploy this VM. This field may be used to specify the name of a VirtualMachineImage or ClusterVirtualMachineImage resource. |
| `spec.instanceUUID` | string |  |  | InstanceUUID describes the desired Instance UUID for a VM. If omitted, this field defaults to a random UUID. This value is only used for the VM Instance UUID, it is not used within cloudInit. |
| `spec.minHardwareVersion` | integer |  |  | MinHardwareVersion describes the desired, minimum hardware version. The logic that determines the hardware version is as follows: 1. |
| `spec.network` | object |  |  | Network describes the desired network configuration for the VM. |
| `spec.network.disabled` | boolean |  |  | Disabled is a flag that indicates whether or not to disable networking for this VM. |
| `spec.network.domainName` | string |  |  | DomainName describes the value the guest uses as its domain name. |
| `spec.network.hostName` | string |  |  | HostName describes the value the guest uses as its host name. If omitted, the name of the VM will be used. |
| `spec.network.interfaces` | array of object |  |  | Interfaces is the list of network interfaces used by this VM. If the Interfaces field is empty and the Disabled field is false, then a default interface with the name eth0 will be created. |
| `spec.network.interfaces[].addresses` | array of string |  |  | Addresses is an optional list of IP4 or IP6 addresses to assign to this interface. 192.168.0.10/24 or 2001:db8:101::a/64. |
| `spec.network.interfaces[].dhcp4` | boolean |  |  | DHCP4 indicates whether or not this interface uses DHCP for IP4 networking. |
| `spec.network.interfaces[].dhcp6` | boolean |  |  | DHCP6 indicates whether or not this interface uses DHCP for IP6 networking. |
| `spec.network.interfaces[].gateway4` | string |  |  | Gateway4 is the default, IP4 gateway for this interface. If unset, the gateway from the network provider will be used. |
| `spec.network.interfaces[].gateway6` | string |  |  | Gateway6 is the primary IP6 gateway for this interface. If unset, the gateway from the network provider will be used. |
| `spec.network.interfaces[].guestDeviceName` | string |  |  | GuestDeviceName is used to rename the device inside the guest when the bootstrap provider is Cloud-Init. dvd, cdrom, sda, etc. |
| `spec.network.interfaces[].macAddr` | string |  |  | MACAddr is the optional MAC address of this interface. If no MAC address is provided, one will be generated by either the network provider or vCenter.nsx.vmware.com. |
| `spec.network.interfaces[].mtu` | integer |  |  | MTU is the Maximum Transmission Unit size in bytes. |
| `spec.network.interfaces[].name` | string | yes |  | Name describes the unique name of this network interface, used to distinguish it from other network interfaces attached to this VM. |
| `spec.network.interfaces[].nameservers` | array of string |  |  | Nameservers is a list of IP4 and/or IP6 addresses used as DNS nameservers. |
| `spec.network.interfaces[].network` | object |  |  | Network is the name of the network resource to which this interface is connected. If no network is provided, then this interface will be connected to the Namespace's default network. |
| `spec.network.interfaces[].network.apiVersion` | string |  |  | APIVersion defines the versioned schema of this representation of an object. Servers should convert recognized schemas to the latest internal value, and may reject unrecognized values. |
| `spec.network.interfaces[].network.kind` | string |  |  | Kind is a string value representing the REST resource this object represents. Servers may infer this from the endpoint the client submits requests to. |
| `spec.network.interfaces[].network.name` | string | yes |  | Name refers to a unique resource in the current namespace. |
| `spec.network.interfaces[].routes` | array of object |  |  | Routes is a list of optional, static routes. |
| `spec.network.interfaces[].routes[].metric` | integer |  |  | Metric is the weight/priority of the route. |
| `spec.network.interfaces[].routes[].to` | string | yes |  | To is either "default", or an IP4 or IP6 address. |
| `spec.network.interfaces[].routes[].via` | string | yes |  | Via is an IP4 or IP6 address. |
| `spec.network.interfaces[].searchDomains` | array of string |  |  | SearchDomains is a list of search domains used when resolving IP addresses with DNS. |
| `spec.network.nameservers` | array of string |  |  | Nameservers is a list of IP4 and/or IP6 addresses used as DNS nameservers. These are applied globally. The Cloud-Init bootstrap provider supports per-interface nameservers. |
| `spec.network.searchDomains` | array of string |  |  | SearchDomains is a list of search domains used when resolving IP addresses with DNS. These are applied globally. The Cloud-Init bootstrap provider supports per-interface search domains. |
| `spec.nextRestartTime` | string |  |  | NextRestartTime may be used to restart the VM, in accordance with RestartMode, by setting the value of this field to "now" (case-insensitive). |
| `spec.policies` | array of object |  |  | Policies describes a list of policies that should be explicitly applied to this VM. Please consult a policy to determine if it may be applied directly. |
| `spec.policies[].apiVersion` | string | yes |  | APIVersion defines the versioned schema of this representation of an object. |
| `spec.policies[].kind` | string | yes |  | Kind is a string value representing the REST resource this object represents. Servers may infer this from the endpoint the client submits requests to. |
| `spec.policies[].name` | string | yes |  | Name refers to a unique resource in the current namespace. |
| `spec.powerOffMode` | string |  | `Hard`, `Soft`, `TrySoft`; default `TrySoft` | PowerOffMode describes the desired behavior when powering off a VM. There are three, supported power off modes: Hard, Soft, and TrySoft. |
| `spec.powerState` | string |  | `PoweredOff`, `PoweredOn`, `Suspended` | PowerState describes the desired power state of a VirtualMachine." However, once the field is set to a non-empty value, it may no longer be set to an empty value. |
| `spec.promoteDisksMode` | string |  | `Online`, `Offline`, `Disabled`; default `Online` | PromoteDisksMode describes the mode used to promote a VM's delta disks to full disks. The available modes are: - Disabled -- Do not promote disks. |
| `spec.readinessProbe` | object |  |  | ReadinessProbe describes a probe used to determine the VM's ready state. |
| `spec.readinessProbe.guestHeartbeat` | object |  |  | GuestHeartbeat specifies an action involving the guest heartbeat status. |
| `spec.readinessProbe.guestHeartbeat.thresholdStatus` | string |  | `yellow`, `green`; default `green` | ThresholdStatus is the value that the guest heartbeat status must be at or above to be considered successful. |
| `spec.readinessProbe.guestInfo` | array of object |  |  | GuestInfo specifies an action involving key/value pairs from GuestInfo. |
| `spec.readinessProbe.guestInfo[].key` | string | yes |  | Key is the name of the GuestInfo key. The key is automatically prefixed with "guestinfo." before being evaluated. |
| `spec.readinessProbe.guestInfo[].value` | string |  |  | Value is a regular expression that is matched against the value of the specified key. An empty value is the equivalent of "match any" or ".*". |
| `spec.readinessProbe.periodSeconds` | integer |  |  | PeriodSeconds specifics how often (in seconds) to perform the probe. Defaults to 10 seconds. Minimum value is 1. |
| `spec.readinessProbe.tcpSocket` | object |  |  | TCPSocket specifies an action involving a TCP port. Deprecated: The TCPSocket action requires network connectivity that is not supported in all environments. |
| `spec.readinessProbe.tcpSocket.host` | string |  |  | Host is an optional host name to connect to. Host defaults to the VM IP. |
| `spec.readinessProbe.tcpSocket.port` | int or string | yes |  | Port specifies a number or name of the port to access on the VM. If the format of port is a number, it must be in the range 1 to 65535. |
| `spec.readinessProbe.timeoutSeconds` | integer |  |  | TimeoutSeconds specifies a number of seconds after which the probe times out. Defaults to 10 seconds. Minimum value is 1. |
| `spec.reserved` | object |  |  | Reserved describes a set of VM configuration options reserved for system use. |
| `spec.reserved.resourcePolicyName` | string |  |  |  |
| `spec.restartMode` | string |  | `Hard`, `Soft`, `TrySoft`; default `TrySoft` | RestartMode describes the desired behavior for restarting a VM when spec.nextRestartTime is set to "now" (case-insensitive). |
| `spec.storageClass` | string |  |  | StorageClass describes the name of a Kubernetes StorageClass resource used to configure this VM's storage-related attributes. |
| `spec.suspendMode` | string |  | `Hard`, `Soft`, `TrySoft`; default `TrySoft` | SuspendMode describes the desired behavior when suspending a VM. There are three, supported suspend modes: Hard, Soft, and TrySoft. |
| `spec.volumes` | array of object |  |  | Volumes describes a list of volumes that can be mounted to the VM. |
| `spec.volumes[].applicationType` | string |  | `OracleRAC`, `MicrosoftWSFC` | ApplicationType describes the type of application for which this volume is intended to be used. |
| `spec.volumes[].controllerBusNumber` | integer |  |  | ControllerBusNumber describes the bus number of the controller to which this volume should be attached. |
| `spec.volumes[].controllerType` | string |  | `IDE`, `NVME`, `SCSI`, `SATA` | ControllerType describes the type of the controller to which this volume should be attached. |
| `spec.volumes[].diskMode` | string |  | `IndependentNonPersistent`, `IndependentPersistent`, `NonPersistent`, `Persistent` | DiskMode describes the desired mode to use when attaching the volume. |
| `spec.volumes[].name` | string | yes |  | Name represents the volume's name. Must be a DNS_LABEL and unique within the VM. |
| `spec.volumes[].persistentVolumeClaim` | object |  |  | PersistentVolumeClaim represents a reference to a PersistentVolumeClaim in the same namespace. |
| `spec.volumes[].persistentVolumeClaim.claimName` | string | yes |  | claimName is the name of a PersistentVolumeClaim in the same namespace as the pod using this volume. |
| `spec.volumes[].persistentVolumeClaim.instanceVolumeClaim` | object |  |  | InstanceVolumeClaim is set if the PVC is backed by instance storage. |
| `spec.volumes[].persistentVolumeClaim.instanceVolumeClaim.size` | int or string | yes |  | Size is the size of the requested instance storage volume. |
| `spec.volumes[].persistentVolumeClaim.instanceVolumeClaim.storageClass` | string | yes |  | StorageClass is the name of the Kubernetes StorageClass that provides the backing storage for this instance storage volume. |
| `spec.volumes[].persistentVolumeClaim.readOnly` | boolean |  |  | readOnly Will force the ReadOnly setting in VolumeMounts. Default false. |
| `spec.volumes[].removable` | boolean |  | default `true` | Removable describes whether or not this volume may be removed from spec.volumes. |
| `spec.volumes[].sharingMode` | string |  | `MultiWriter`, `None` | SharingMode describes the volume's desired sharing mode. When applicationType=OracleRAC, this field defaults to MultiWriter. |
| `spec.volumes[].unitNumber` | integer |  |  | UnitNumber describes the desired unit number for attaching the volume to a storage controller. When omitted, the next available unit number of the selected controller is used. |

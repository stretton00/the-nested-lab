| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.preferredDefaultSNATIP` | string |  | e.g. `192.168.144.30` | PreferredDefaultSNATIP specifies the translated IP for VPC auto SNAT rules. The specified IP must be available. |
| `spec.vpcConnectivityProfileName` | string | yes | e.g. `default--f06` | VPCConnectivityProfileName specifies the name of the VPC Connectivity Profile associated with the VPC. |

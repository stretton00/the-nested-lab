| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.preferredDefaultSNATIP` | string |  |  | PreferredDefaultSNATIP specifies the translated IP for VPC auto SNAT rules. The specified IP must be available. |
| `spec.vpcConnectivityProfileName` | string | yes | default `` | VPCConnectivityProfileName specifies the name of the VPC Connectivity Profile associated with the VPC. |

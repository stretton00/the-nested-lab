| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.bootOrder` | array of object |  |  | BootOrder describes the boot sequence for this group members. Each boot order contains a set of members that will be powered on simultaneously, with an optional delay before powering on. |
| `spec.bootOrder[].members` | array of object |  |  | Members describes the names of VirtualMachine or VirtualMachineGroup objects that are members of this boot order group. |
| `spec.bootOrder[].members[].kind` | string |  | `VirtualMachine`, `VirtualMachineGroup`; default `VirtualMachine` | Kind is the kind of member of this group, which can be either VirtualMachine or VirtualMachineGroup. If omitted, it defaults to VirtualMachine. |
| `spec.bootOrder[].members[].name` | string | yes |  | Name is the name of member of this group. |
| `spec.bootOrder[].powerOnDelay` | string |  |  | PowerOnDelay is the amount of time to wait before powering on all the members of this boot order group. |
| `spec.groupName` | string |  |  | GroupName describes the name of the group that this group belongs to. |
| `spec.nextForcePowerStateSyncTime` | string |  |  | NextForcePowerStateSyncTime may be used to force sync the power state of the group to all of its members, by setting the value of this field to "now" (case-insensitive). |
| `spec.powerOffMode` | string |  | `Hard`, `Soft`, `TrySoft` | PowerOffMode describes the desired behavior when powering off a VM Group. Refer to the VirtualMachine.PowerOffMode field for more details. |
| `spec.powerState` | string |  | `PoweredOff`, `PoweredOn`, `Suspended` | PowerState describes the desired power state of a VirtualMachineGroup. |
| `spec.suspendMode` | string |  | `Hard`, `Soft`, `TrySoft` | SuspendMode describes the desired behavior when suspending a VM Group. Refer to the VirtualMachine.SuspendMode field for more details. |

| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `data` | object |  |  | Data contains the secret data. Each key must consist of alphanumeric characters, '-', '_' or '.'. |
| `immutable` | boolean |  |  | Immutable, if set to true, ensures that data stored in the Secret cannot be updated (only object metadata can be modified). |
| `stringData` | object |  |  | stringData allows specifying non-binary secret data in string form. It is provided as a write-only input field for convenience. |
| `type` | string |  |  | Used to facilitate programmatic handling of secret data. |

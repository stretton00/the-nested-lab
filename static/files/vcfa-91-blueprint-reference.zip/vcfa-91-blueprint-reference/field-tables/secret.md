| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `data` | object |  | e.g. `{password: <base64>}` | Data contains the secret data. Each key must consist of alphanumeric characters, '-', '_' or '.'. |
| `immutable` | boolean |  | e.g. `true` | Immutable, if set to true, ensures that data stored in the Secret cannot be updated (only object metadata can be modified). |
| `stringData` | object |  | e.g. `{password: ${input.password}}` | stringData allows specifying non-binary secret data in string form. It is provided as a write-only input field for convenience. |
| `type` | string |  | e.g. `Opaque` | Used to facilitate programmatic handling of secret data. |

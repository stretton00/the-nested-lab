| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.ipAddresses` | array of string |  | e.g. `[10.200.0.0/28]` | List of IPs or CIDRs to be included in this VPCNetworkSecurityGroup. Each entry can be a single IP address, an IP range, or a subnet in CIDR notation. |
| `spec.podSelectors` | array of object |  | e.g. `[{labelSelector: {matchLabels: {app: web}}, ...}]` | List of Pod label selectors that will dynamically select Pods to include in this VPCNetworkSecurityGroup. |
| `spec.podSelectors[].labelSelector` | object |  | e.g. `{matchLabels: {app: web}}` | A label selector is a label query over a set of resources. The result of matchLabels and matchExpressions are ANDed. |
| `spec.podSelectors[].labelSelector.matchExpressions` | array of object |  | e.g. `[{key: app, operator: In}]` | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.podSelectors[].labelSelector.matchExpressions[].key` | string | yes | e.g. `app` | key is the label key that the selector applies to. |
| `spec.podSelectors[].labelSelector.matchExpressions[].operator` | string | yes | e.g. `In` | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.podSelectors[].labelSelector.matchExpressions[].values` | array of string |  | e.g. `[web]` | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.podSelectors[].labelSelector.matchLabels` | object |  | e.g. `{app: web}` | matchLabels is a map of {key,value} pairs. |
| `spec.podSelectors[].namespaceSelector` | object |  | e.g. `{matchExpressions: [{key: app, operator: In}], matchLabels: {app: web}}` | A label selector is a label query over a set of resources. The result of matchLabels and matchExpressions are ANDed. |
| `spec.podSelectors[].namespaceSelector.matchExpressions` | array of object |  | e.g. `[{key: app, operator: In}]` | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.podSelectors[].namespaceSelector.matchExpressions[].key` | string | yes | e.g. `app` | key is the label key that the selector applies to. |
| `spec.podSelectors[].namespaceSelector.matchExpressions[].operator` | string | yes | e.g. `In` | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.podSelectors[].namespaceSelector.matchExpressions[].values` | array of string |  | e.g. `[web]` | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.podSelectors[].namespaceSelector.matchLabels` | object |  | e.g. `{app: web}` | matchLabels is a map of {key,value} pairs. |
| `spec.vmSelectors` | array of object |  | e.g. `[{labelSelector: {matchLabels: {app: web}}, ...}]` | List of Virtual Machine label selectors that will dynamically select VMs to include in this VPCNetworkSecurityGroup. |
| `spec.vmSelectors[].labelSelector` | object |  | e.g. `{matchLabels: {app: web}}` | A label selector is a label query over a set of resources. The result of matchLabels and matchExpressions are ANDed. |
| `spec.vmSelectors[].labelSelector.matchExpressions` | array of object |  | e.g. `[{key: app, operator: In}]` | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.vmSelectors[].labelSelector.matchExpressions[].key` | string | yes | e.g. `app` | key is the label key that the selector applies to. |
| `spec.vmSelectors[].labelSelector.matchExpressions[].operator` | string | yes | e.g. `In` | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.vmSelectors[].labelSelector.matchExpressions[].values` | array of string |  | e.g. `[web]` | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.vmSelectors[].labelSelector.matchLabels` | object |  | e.g. `{app: web}` | matchLabels is a map of {key,value} pairs. |
| `spec.vmSelectors[].namespaceSelector` | object |  | e.g. `{matchExpressions: [{key: app, operator: In}], matchLabels: {app: web}}` | A label selector is a label query over a set of resources. The result of matchLabels and matchExpressions are ANDed. |
| `spec.vmSelectors[].namespaceSelector.matchExpressions` | array of object |  | e.g. `[{key: app, operator: In}]` | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.vmSelectors[].namespaceSelector.matchExpressions[].key` | string | yes | e.g. `app` | key is the label key that the selector applies to. |
| `spec.vmSelectors[].namespaceSelector.matchExpressions[].operator` | string | yes | e.g. `In` | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.vmSelectors[].namespaceSelector.matchExpressions[].values` | array of string |  | e.g. `[web]` | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.vmSelectors[].namespaceSelector.matchLabels` | object |  | e.g. `{app: web}` | matchLabels is a map of {key,value} pairs. |
| `spec.vmSelectors[].propertySelector` | object |  | e.g. `{matchExpressions: [{key: Name, operator: StartsWith}]}` | PropertySelector represents a set of conditions on VM properties. All MatchExpressions are ANDed; a VM must satisfy all expressions to match. |
| `spec.vmSelectors[].propertySelector.matchExpressions` | array of object |  | e.g. `[{key: Name, operator: StartsWith}]` | MatchExpressions is a list of property selector requirements. Each requirement consists of a key, operator, and value. |
| `spec.vmSelectors[].propertySelector.matchExpressions[].key` | string | yes | e.g. `Name` | Key is the VM property to match. Valid keys are Name, OSName and ComputerName. |
| `spec.vmSelectors[].propertySelector.matchExpressions[].operator` | string | yes | e.g. `StartsWith` | Operator defines how the Key is compared against Value. Valid operators are Equals, Contains, StartsWith, EndsWith and NotEquals. |
| `spec.vmSelectors[].propertySelector.matchExpressions[].value` | string | yes | e.g. `web-` | Value is the target value to match against the VM property. |
| `spec.vms` | array of object |  | e.g. `[{instanceUUID: 5010c9b4-1f2e-4d3c-8b7a-6e5f4d3c2b1a}]` | List of Virtual Machine references that will be included in this VPCNetworkSecurityGroup. |
| `spec.vms[].instanceUUID` | string | yes | e.g. `5010c9b4-1f2e-4d3c-8b7a-6e5f4d3c2b1a` | InstanceUUID of the VM being referenced. |
| `spec.vpcNetworkSecurityGroupNames` | array of string |  | e.g. `[db-servers]` | List of VPCNetworkSecurityGroup names that will be included in this VPCNetworkSecurityGroup. |

| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.ipAddresses` | array of string |  |  | List of IPs or CIDRs to be included in this VPCNetworkSecurityGroup. Each entry can be a single IP address, an IP range, or a subnet in CIDR notation. |
| `spec.podSelectors` | array of object |  |  | List of Pod label selectors that will dynamically select Pods to include in this VPCNetworkSecurityGroup. |
| `spec.podSelectors[].labelSelector` | object |  |  | A label selector is a label query over a set of resources. The result of matchLabels and matchExpressions are ANDed. |
| `spec.podSelectors[].labelSelector.matchExpressions` | array of object |  |  | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.podSelectors[].labelSelector.matchExpressions[].key` | string | yes | default `` | key is the label key that the selector applies to. |
| `spec.podSelectors[].labelSelector.matchExpressions[].operator` | string | yes | default `` | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.podSelectors[].labelSelector.matchExpressions[].values` | array of string |  |  | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.podSelectors[].labelSelector.matchLabels` | object |  |  | matchLabels is a map of {key,value} pairs. |
| `spec.podSelectors[].namespaceSelector` | object |  |  | A label selector is a label query over a set of resources. The result of matchLabels and matchExpressions are ANDed. |
| `spec.podSelectors[].namespaceSelector.matchExpressions` | array of object |  |  | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.podSelectors[].namespaceSelector.matchExpressions[].key` | string | yes | default `` | key is the label key that the selector applies to. |
| `spec.podSelectors[].namespaceSelector.matchExpressions[].operator` | string | yes | default `` | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.podSelectors[].namespaceSelector.matchExpressions[].values` | array of string |  |  | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.podSelectors[].namespaceSelector.matchLabels` | object |  |  | matchLabels is a map of {key,value} pairs. |
| `spec.vmSelectors` | array of object |  |  | List of Virtual Machine label selectors that will dynamically select VMs to include in this VPCNetworkSecurityGroup. |
| `spec.vmSelectors[].labelSelector` | object |  |  | A label selector is a label query over a set of resources. The result of matchLabels and matchExpressions are ANDed. |
| `spec.vmSelectors[].labelSelector.matchExpressions` | array of object |  |  | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.vmSelectors[].labelSelector.matchExpressions[].key` | string | yes | default `` | key is the label key that the selector applies to. |
| `spec.vmSelectors[].labelSelector.matchExpressions[].operator` | string | yes | default `` | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.vmSelectors[].labelSelector.matchExpressions[].values` | array of string |  |  | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.vmSelectors[].labelSelector.matchLabels` | object |  |  | matchLabels is a map of {key,value} pairs. |
| `spec.vmSelectors[].namespaceSelector` | object |  |  | A label selector is a label query over a set of resources. The result of matchLabels and matchExpressions are ANDed. |
| `spec.vmSelectors[].namespaceSelector.matchExpressions` | array of object |  |  | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.vmSelectors[].namespaceSelector.matchExpressions[].key` | string | yes | default `` | key is the label key that the selector applies to. |
| `spec.vmSelectors[].namespaceSelector.matchExpressions[].operator` | string | yes | default `` | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.vmSelectors[].namespaceSelector.matchExpressions[].values` | array of string |  |  | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.vmSelectors[].namespaceSelector.matchLabels` | object |  |  | matchLabels is a map of {key,value} pairs. |
| `spec.vmSelectors[].propertySelector` | object |  |  | PropertySelector represents a set of conditions on VM properties. All MatchExpressions are ANDed; a VM must satisfy all expressions to match. |
| `spec.vmSelectors[].propertySelector.matchExpressions` | array of object |  |  | MatchExpressions is a list of property selector requirements. Each requirement consists of a key, operator, and value. |
| `spec.vmSelectors[].propertySelector.matchExpressions[].key` | string | yes | default `` | Key is the VM property to match. Valid keys are Name, OSName and ComputerName. |
| `spec.vmSelectors[].propertySelector.matchExpressions[].operator` | string | yes | default `` | Operator defines how the Key is compared against Value. Valid operators are Equals, Contains, StartsWith, EndsWith and NotEquals. |
| `spec.vmSelectors[].propertySelector.matchExpressions[].value` | string | yes | default `` | Value is the target value to match against the VM property. |
| `spec.vms` | array of object |  |  | List of Virtual Machine references that will be included in this VPCNetworkSecurityGroup. |
| `spec.vms[].instanceUUID` | string | yes | default `` | InstanceUUID of the VM being referenced. |
| `spec.vpcNetworkSecurityGroupNames` | array of string |  |  | List of VPCNetworkSecurityGroup names that will be included in this VPCNetworkSecurityGroup. |

| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.allocationIPs` | string |  | e.g. `192.168.144.18` | The specific IP addresses from IPBlock that needs to be requested. If specified, it should be passed like 192.168.0.0/24 or 192.168.0.1/32. |
| `spec.allocationSize` | integer |  | e.g. `1` | Allocation IP address size for auto allocating IPs from IPBlock. The IP addresses will be auto allocated from unused IP addresses based on allocation size. |
| `spec.ipAddressBlockVisibility` | string |  | e.g. `External` | Visibility of IP address block. Must be External, Private or PrivateTGW. Note: the default Private Visibility is different from NSX API's default External Visibility. |
| `spec.ipBlockName` | string |  | e.g. `:f06-vpc-ext02` | IPBlock name for allocating IP address. |

| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.accessMode` | string |  | `Private`, `Public`, `PrivateTGW`, `L2Only` | Access mode of Subnet, accessible only from within VPC or from outside VPC. |
| `spec.advancedConfig` | object |  | e.g. `{dhcpServerAddresses: [10.200.0.2/28], gatewayAddresses: [10.200.0.1/28]}` | VPC Subnet advanced configuration. |
| `spec.advancedConfig.connectivityState` | string |  | `Connected`, `Disconnected`; default `Connected` | Connectivity status of the Subnet from other Subnets of the VPC. The default value is "Connected". |
| `spec.advancedConfig.dhcpServerAddresses` | array of string |  | e.g. `[10.200.0.2/28]` | DHCPServerAddresses specifies custom DHCP server IP addresses for the Subnet. |
| `spec.advancedConfig.gatewayAddresses` | array of string |  | e.g. `[10.200.0.1/28]` | GatewayAddresses specifies custom gateway IP addresses for the Subnet. |
| `spec.advancedConfig.staticIPAllocation` | object |  | e.g. `{enabled: true}` | Static IP allocation for VPC Subnet Ports. |
| `spec.advancedConfig.staticIPAllocation.enabled` | boolean |  | e.g. `true` | Activate or deactivate static IP allocation for VPC Subnet Ports. If the DHCP mode is DHCPDeactivated or not set, its default value is true. |
| `spec.ipAddresses` | array of string |  | e.g. `[10.200.0.0/28]` | Subnet CIDRS. |
| `spec.ipv4SubnetSize` | integer |  | e.g. `32` | Size of Subnet based upon estimated workload count. |
| `spec.subnetDHCPConfig` | object |  | e.g. `{dhcpServerAdditionalConfig: {reservedIPRanges: [10.200.0.10-10.200.0.15]}, ...}` | DHCP configuration for Subnet. |
| `spec.subnetDHCPConfig.dhcpServerAdditionalConfig` | object |  | e.g. `{reservedIPRanges: [10.200.0.10-10.200.0.15]}` | Additional DHCP server config for a VPC Subnet. |
| `spec.subnetDHCPConfig.dhcpServerAdditionalConfig.reservedIPRanges` | array of string |  | e.g. `[10.200.0.10-10.200.0.15]` | Reserved IP ranges. Supported formats include: ["192.168.1.1", "192.168.1.3-192.168.1.100"] |
| `spec.subnetDHCPConfig.mode` | string |  | `DHCPServer`, `DHCPRelay`, `DHCPDeactivated` | DHCP Mode. DHCPDeactivated will be used if it is not defined. It cannot switch from DHCPDeactivated to DHCPServer or DHCPRelay. |
| `spec.vlanConnectionName` | string |  | e.g. `<distributed VLAN connection>` | Distributed VLAN Connection name. |
| `spec.vpcName` | string |  | e.g. `${resource.vpc.name}` | VPC name of the Subnet. |

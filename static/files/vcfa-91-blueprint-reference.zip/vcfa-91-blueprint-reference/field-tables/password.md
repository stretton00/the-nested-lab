| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `count` | integer |  | default `1` | The number of resource instances to be created. |
| `length` | integer |  | default `14` | Length of the password to be auto generated |
| `password` | string |  | e.g. `${input.adminPassword}` | Password value received as an input when length is not specified |

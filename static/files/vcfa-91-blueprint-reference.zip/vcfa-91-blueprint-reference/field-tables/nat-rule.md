| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.action` | string | yes | default `` | Action represents action of NAT Rule. Valid values: SNAT, DNAT, Reflexive, NoSNAT and NoDNAT. |
| `spec.destinationNetwork` | string |  |  | DestinationNetwork represents the destination network. The value can be a single IPv4 address or CIDR, or a comma separated list of IPv4 addresses. |
| `spec.enabled` | boolean |  |  | NAT Rule enabled flag Enabled indicates whether the NAT rule is enabled or disabled. The default is True. |
| `spec.firewallMatch` | string |  |  | FirewallMatch indicates how the firewall matches the address after NATing if firewall stage is not skipped. |
| `spec.logging` | boolean |  |  | NAT Rule logging flag Logging indicates whether the logging of NAT rule is enabled or disabled. The default is False. |
| `spec.sequenceNumber` | integer |  | default `0` | SequenceNumber decides the priority of a NAT rule. Valid range is [0, 2147481599]. Default is 0. |
| `spec.serviceEntry` | object |  |  |  |
| `spec.serviceEntry.destinationPorts` | string |  |  | The destination ports to match. If specified, it must be either a single port (e.g. "8080") or a port range (e.g. "8090-8095"). |
| `spec.serviceEntry.protocol` | string | yes | default `` | Protocol supports TCP, UDP and ICMP v4. |
| `spec.serviceEntry.sourcePorts` | string |  |  | The source ports to match. If specified, it must be either a single port (e.g. "8080") or a port range (e.g. "8090-8095"). |
| `spec.serviceEntry.translatedPorts` | string |  |  | The translated ports. If specified, it must be either a single port (e.g. "8080") or a port range (e.g. "8090-8095"). |
| `spec.sourceNetwork` | string |  |  | SourceNetwork represents the source network address. The value can be a single IPv4 address or CIDR, or a comma separated list of IPv4 addresses. |
| `spec.translatedNetwork` | string | yes | default `` | TranslatedNetwork represents the translated network address. The field is required and must contain a single IPv4 address for SNAT, DNAT and Reflexive. |

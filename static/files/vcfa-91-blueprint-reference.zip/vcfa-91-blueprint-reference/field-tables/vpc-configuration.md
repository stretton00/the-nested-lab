| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `vpc` | string | yes |  | ID of the parent VPC this resource is associated with. |
| `kind` | string | yes |  | The kind of the resource (e.g., VPCNetworkSecurityGroup, VPCIPAddressAllocation, VPCNATRule, VPCAttachment). |
| `wait` | object |  |  | Wait conditions applied to all config resources. All resources must satisfy these conditions before the operation is considered complete. |
| `wait.fields` | array of object |  |  | List of field conditions to wait for. |
| `wait.fields[].path` | string | yes |  | JSONPath to the field to check (e.g., status.phase). |
| `wait.fields[].value` | string | yes |  | The expected value of the field. Use '*' for any non-null value. |
| `wait.fields[].indicatesFailure` | boolean |  | default `false` | Whether this field condition indicates a failure state. |
| `wait.conditions` | array of object |  |  | List of status conditions to wait for. |
| `wait.conditions[].type` | string | yes |  | The type of the condition (e.g., Ready, Realized). |
| `wait.conditions[].reason` | string |  |  | Optional reason for the condition. |
| `wait.conditions[].status` | string | yes |  | The expected status of the condition (e.g., True, False). |
| `wait.conditions[].indicatesFailure` | boolean |  | default `false` | Whether this condition indicates a failure state. |
| `wait.skipWaitOnDelete` | boolean |  | default `false` | Whether to skip waiting for conditions during delete operations. |
| `count` | integer |  | default `1` | The number of resource instances to be created. |
| `configs` | array of object | yes |  | List of resources associated with the VPC. |
| `configs[].spec` | object |  |  | The specification of the associated resource. |
| `configs[].labels` | object |  |  | Labels for categorizing the resource. |
| `configs[].annotations` | object |  |  | Annotations for additional metadata about the resource. |
| `configs[].generateName` | string | yes |  | A prefix for generating a unique name for the resource. |
| `apiVersion` | string |  |  | The API version of the resource. |

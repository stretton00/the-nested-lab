| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `vpc` | string | yes | e.g. `${resource.vpc.id}` | ID of the parent VPC this resource is associated with. |
| `kind` | string | yes | e.g. `VPCNATRule` | The kind of the resource (e.g., VPCNetworkSecurityGroup, VPCIPAddressAllocation, VPCNATRule, VPCAttachment). |
| `wait` | object |  | e.g. `{fields: [{path: status.conditions[0].status, value: True}], ...}` | Wait conditions applied to all config resources. All resources must satisfy these conditions before the operation is considered complete. |
| `wait.fields` | array of object |  | e.g. `[{path: status.conditions[0].status, value: True}]` | List of field conditions to wait for. |
| `wait.fields[].path` | string | yes | e.g. `status.conditions[0].status` | JSONPath to the field to check (e.g., status.phase). |
| `wait.fields[].value` | string | yes | e.g. `True` | The expected value of the field. Use '*' for any non-null value. |
| `wait.fields[].indicatesFailure` | boolean |  | default `false` | Whether this field condition indicates a failure state. |
| `wait.conditions` | array of object |  | e.g. `[{type: Realized, reason: <condition reason>}]` | List of status conditions to wait for. |
| `wait.conditions[].type` | string | yes | e.g. `Realized` | The type of the condition (e.g., Ready, Realized). |
| `wait.conditions[].reason` | string |  | e.g. `<condition reason>` | Optional reason for the condition. |
| `wait.conditions[].status` | string | yes | e.g. `True` | The expected status of the condition (e.g., True, False). |
| `wait.conditions[].indicatesFailure` | boolean |  | default `false` | Whether this condition indicates a failure state. |
| `wait.skipWaitOnDelete` | boolean |  | default `false` | Whether to skip waiting for conditions during delete operations. |
| `count` | integer |  | default `1` | The number of resource instances to be created. |
| `configs` | array of object | yes | e.g. `[{generateName: dnat-web, spec: {action: DNAT, translatedNetwork: 10.200.0.10}}]` | List of resources associated with the VPC. |
| `configs[].spec` | object |  | e.g. `{action: DNAT, translatedNetwork: 10.200.0.10}` | The specification of the associated resource. |
| `configs[].labels` | object |  | e.g. `{app: web}` | Labels for categorizing the resource. |
| `configs[].annotations` | object |  | e.g. `{owner: team-a}` | Annotations for additional metadata about the resource. |
| `configs[].generateName` | string | yes | e.g. `dnat-web` | A prefix for generating a unique name for the resource. |
| `apiVersion` | string |  | e.g. `vpc.nsx.vmware.com/v1alpha1` | The API version of the resource. |

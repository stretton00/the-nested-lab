| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.category` | string |  |  | Pre-defined categories for classifying a VPC Gateway Firewall policy.There are two pre-defined categories. They are "LocalGatewayRules" and "Default". |
| `spec.description` | string |  |  | Description for the firewall policy. |
| `spec.isDefault` | boolean |  | default `false` | A flag to indicate whether rule is a default rule |
| `spec.locked` | boolean |  | default `false` | Locked indicates whether a security policy should be locked |
| `spec.priority` | integer |  | default `0` | This field is used to resolve conflicts between multiple Rules under Security or Gateway Policy for a Domain. If no priority is specified in the payload, a value of 0 is assigned by default. |
| `spec.rules` | array of object |  |  | Rules that are a part of this FirewallPolicy |
| `spec.rules[].action` | string |  |  | Action to be applied to all the services |
| `spec.rules[].appliedTo` | object |  |  |  |
| `spec.rules[].appliedTo.gatewayAttachmentNames` | array of string |  |  | This field is only applicable when the rule is defined for Transit Gateway Firewall policy |
| `spec.rules[].appliedTo.gatewayNames` | array of string |  |  | This field is only applicable when the rule is defined for Transit Gateway Firewall policy |
| `spec.rules[].appliedTo.groupNames` | array of string |  |  | This field is only applicable when the rule is defined for Distributed Firewall policy |
| `spec.rules[].destinationsExcluded` | boolean |  |  | DestinationsExcluded indicates that the rule applies to all destinations *except* those specified in the 'To' field. |
| `spec.rules[].direction` | string |  |  | Direction defines direction of traffic. |
| `spec.rules[].disabled` | boolean |  | default `false` | Disabled indicates if the rule is enabled/disabled. |
| `spec.rules[].from` | array of object |  |  | From defines the source of the traffic. If empty, it defaults to "Any", matching all sources. |
| `spec.rules[].from[].groupName` | string |  |  |  |
| `spec.rules[].from[].ipAddress` | string |  |  |  |
| `spec.rules[].ipProtocol` | string |  |  | IpProtocol indicates type of IP packet that should be matched while enforcing the rule. Only IPV_4 protocol is supported for new rules, IPV4_IPV6 is only allowed for default rules. |
| `spec.rules[].isDefault` | boolean |  | default `false` | IsDefault is a flag to indicate whether rule is a default rule. |
| `spec.rules[].log` | boolean |  |  | Log indicates if traffic matching this rule should be logged. |
| `spec.rules[].name` | string | yes | default `` | Name for the rule. Must be unique within the policy. |
| `spec.rules[].notes` | string |  |  | Notes for the rule. |
| `spec.rules[].services` | array of object |  |  | Services specifies the network services (protocols and ports) to which this rule applies. If empty or null ,it defaults to "Any" , then this rule applies to all services. |
| `spec.rules[].services[].l4PortSet` | object |  |  | L4PortSetServiceEntry is a ServiceEntry that represents TCP or UDP protocol. |
| `spec.rules[].services[].l4PortSet.destinationPorts` | array of string |  |  | DestinationPorts defines the destination port or port range to match. For example: ["443"], ["8080-8090"]. If empty, matches any destination port. |
| `spec.rules[].services[].l4PortSet.l4Protocol` | string | yes | default `` | L4Protocol specifies the Layer 4 protocol (TCP or UDP). |
| `spec.rules[].services[].l4PortSet.sourcePorts` | array of string |  |  | SourcePorts defines the source port or port range to match. For example: ["80"], ["1000-2000"]. If empty, matches any source port. |
| `spec.rules[].services[].networkServiceName` | string |  |  |  |
| `spec.rules[].sourcesExcluded` | boolean |  |  | SourcesExcluded indicates that the rule applies to all sources *except* those specified in the 'From' field. When true, the 'From' field acts as an exclusion list. |
| `spec.rules[].tag` | string |  |  | Tag applied on the rule. |
| `spec.rules[].to` | array of object |  |  | To defines the destination of the traffic. If empty, it defaults to "Any", matching all destinations. |
| `spec.rules[].to[].groupName` | string |  |  |  |
| `spec.rules[].to[].ipAddress` | string |  |  |  |
| `spec.stateful` | boolean |  | default `false` | Stateful or Stateless nature of security policy is enforced on all rules in this security policy. |
| `spec.tcpStrict` | boolean |  | default `false` | Ensures that a 3 way TCP handshake is done before the data packets are sent. tcp_strict=true is supported only for stateful security policies. |

| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.category` | string |  | e.g. `LocalGatewayRules` | Pre-defined categories for classifying a VPC Gateway Firewall policy.There are two pre-defined categories. They are "LocalGatewayRules" and "Default". |
| `spec.description` | string |  | e.g. `Inbound HTTPS` | Description for the firewall policy. |
| `spec.isDefault` | boolean |  | default `false` | A flag to indicate whether rule is a default rule |
| `spec.locked` | boolean |  | default `false` | Locked indicates whether a security policy should be locked |
| `spec.priority` | integer |  | default `0` | This field is used to resolve conflicts between multiple Rules under Security or Gateway Policy for a Domain. If no priority is specified in the payload, a value of 0 is assigned by default. |
| `spec.rules` | array of object |  | e.g. `[{action: Allow, name: https-in}]` | Rules that are a part of this FirewallPolicy |
| `spec.rules[].action` | string |  | e.g. `Allow` | Action to be applied to all the services |
| `spec.rules[].appliedTo` | object |  | e.g. `{gatewayAttachmentNames: [<transit gateway attachment>], ...}` |  |
| `spec.rules[].appliedTo.gatewayAttachmentNames` | array of string |  | e.g. `[<transit gateway attachment>]` | This field is only applicable when the rule is defined for Transit Gateway Firewall policy |
| `spec.rules[].appliedTo.gatewayNames` | array of string |  | e.g. `[<transit gateway>]` | This field is only applicable when the rule is defined for Transit Gateway Firewall policy |
| `spec.rules[].appliedTo.groupNames` | array of string |  | e.g. `[<group>]` | This field is only applicable when the rule is defined for Distributed Firewall policy |
| `spec.rules[].destinationsExcluded` | boolean |  | e.g. `true` | DestinationsExcluded indicates that the rule applies to all destinations *except* those specified in the 'To' field. |
| `spec.rules[].direction` | string |  | e.g. `In` | Direction defines direction of traffic. |
| `spec.rules[].disabled` | boolean |  | default `false` | Disabled indicates if the rule is enabled/disabled. |
| `spec.rules[].from` | array of object |  | e.g. `[{ipAddress: 0.0.0.0/0, groupName: admin-hosts}]` | From defines the source of the traffic. If empty, it defaults to "Any", matching all sources. |
| `spec.rules[].from[].groupName` | string |  | e.g. `admin-hosts` |  |
| `spec.rules[].from[].ipAddress` | string |  | e.g. `0.0.0.0/0` |  |
| `spec.rules[].ipProtocol` | string |  | e.g. `IPV4` | IpProtocol indicates type of IP packet that should be matched while enforcing the rule. Only IPV_4 protocol is supported for new rules, IPV4_IPV6 is only allowed for default rules. |
| `spec.rules[].isDefault` | boolean |  | default `false` | IsDefault is a flag to indicate whether rule is a default rule. |
| `spec.rules[].log` | boolean |  | e.g. `true` | Log indicates if traffic matching this rule should be logged. |
| `spec.rules[].name` | string | yes | e.g. `https-in` | Name for the rule. Must be unique within the policy. |
| `spec.rules[].notes` | string |  | e.g. `HTTPS from anywhere` | Notes for the rule. |
| `spec.rules[].services` | array of object |  | e.g. `[{l4PortSet: {destinationPorts: [443], l4Protocol: TCP}, networkServiceName: :HTTPS}]` | Services specifies the network services (protocols and ports) to which this rule applies. If empty or null ,it defaults to "Any" , then this rule applies to all services. |
| `spec.rules[].services[].l4PortSet` | object |  | e.g. `{destinationPorts: [443], l4Protocol: TCP}` | L4PortSetServiceEntry is a ServiceEntry that represents TCP or UDP protocol. |
| `spec.rules[].services[].l4PortSet.destinationPorts` | array of string |  | e.g. `[443]` | DestinationPorts defines the destination port or port range to match. For example: ["443"], ["8080-8090"]. If empty, matches any destination port. |
| `spec.rules[].services[].l4PortSet.l4Protocol` | string | yes | e.g. `TCP` | L4Protocol specifies the Layer 4 protocol (TCP or UDP). |
| `spec.rules[].services[].l4PortSet.sourcePorts` | array of string |  | e.g. `[1000-2000]` | SourcePorts defines the source port or port range to match. For example: ["80"], ["1000-2000"]. If empty, matches any source port. |
| `spec.rules[].services[].networkServiceName` | string |  | e.g. `:HTTPS` |  |
| `spec.rules[].sourcesExcluded` | boolean |  | e.g. `true` | SourcesExcluded indicates that the rule applies to all sources *except* those specified in the 'From' field. When true, the 'From' field acts as an exclusion list. |
| `spec.rules[].tag` | string |  | e.g. `web` | Tag applied on the rule. |
| `spec.rules[].to` | array of object |  | e.g. `[{groupName: ${resource.webGroup.configs[0].name}, ipAddress: 10.200.0.10}]` | To defines the destination of the traffic. If empty, it defaults to "Any", matching all destinations. |
| `spec.rules[].to[].groupName` | string |  | e.g. `${resource.webGroup.configs[0].name}` |  |
| `spec.rules[].to[].ipAddress` | string |  | e.g. `10.200.0.10` |  |
| `spec.stateful` | boolean |  | default `false` | Stateful or Stateless nature of security policy is enforced on all rules in this security policy. |
| `spec.tcpStrict` | boolean |  | default `false` | Ensures that a 3 way TCP handshake is done before the data packets are sent. tcp_strict=true is supported only for stateful security policies. |

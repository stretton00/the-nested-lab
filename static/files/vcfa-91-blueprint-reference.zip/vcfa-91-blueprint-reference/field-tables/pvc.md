| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.accessModes` | array of string |  | e.g. `[ReadWriteOnce]` | accessModes contains the desired access modes the volume should have. |
| `spec.dataSource` | object |  | e.g. `{apiGroup: snapshot.storage.k8s.io, kind: <kind>}` | TypedLocalObjectReference contains enough information to let you locate the typed referenced object inside the same namespace. |
| `spec.dataSource.apiGroup` | string |  | e.g. `snapshot.storage.k8s.io` | APIGroup is the group for the resource being referenced. If APIGroup is not specified, the specified Kind must be in the core API group. |
| `spec.dataSource.kind` | string | yes | e.g. `<kind>` | Kind is the type of resource being referenced |
| `spec.dataSource.name` | string | yes | e.g. `<name>` | Name is the name of resource being referenced |
| `spec.dataSourceRef` | object |  | e.g. `{apiGroup: snapshot.storage.k8s.io, namespace: ns-source}` | TypedObjectReference contains enough information to let you locate the typed referenced object |
| `spec.dataSourceRef.apiGroup` | string |  | e.g. `snapshot.storage.k8s.io` | APIGroup is the group for the resource being referenced. If APIGroup is not specified, the specified Kind must be in the core API group. |
| `spec.dataSourceRef.kind` | string | yes | e.g. `<kind>` | Kind is the type of resource being referenced |
| `spec.dataSourceRef.name` | string | yes | e.g. `<name>` | Name is the name of resource being referenced |
| `spec.dataSourceRef.namespace` | string |  | e.g. `ns-source` | Namespace is the namespace of resource being referenced Note that when a namespace is specified, a gateway.networking.k8s.io/ReferenceGrant object is required in the referent namespace to ... |
| `spec.resources` | object |  | e.g. `{limits: {storage: 20Gi}, requests: {storage: 20Gi}}` | VolumeResourceRequirements describes the storage resource requirements for a volume. |
| `spec.resources.limits` | object |  | e.g. `{storage: 20Gi}` | Limits describes the maximum amount of compute resources allowed. |
| `spec.resources.requests` | object |  | e.g. `{storage: 20Gi}` | Requests describes the minimum amount of compute resources required. |
| `spec.selector` | object |  | e.g. `{matchExpressions: [{key: app, operator: In}], matchLabels: {tier: fast}}` | A label selector is a label query over a set of resources. The result of matchLabels and matchExpressions are ANDed. |
| `spec.selector.matchExpressions` | array of object |  | e.g. `[{key: app, operator: In}]` | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.selector.matchExpressions[].key` | string | yes | e.g. `app` | key is the label key that the selector applies to. |
| `spec.selector.matchExpressions[].operator` | string | yes | e.g. `In` | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.selector.matchExpressions[].values` | array of string |  | e.g. `[fast]` | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.selector.matchLabels` | object |  | e.g. `{tier: fast}` | matchLabels is a map of {key,value} pairs. |
| `spec.storageClassName` | string |  | e.g. `vsan-default-storage-policy` | storageClassName is the name of the StorageClass required by the claim. |
| `spec.volumeAttributesClassName` | string |  | e.g. `<volume attributes class>` | volumeAttributesClassName may be used to set the VolumeAttributesClass used by this claim. |
| `spec.volumeMode` | string |  | `Block`, `Filesystem` | volumeMode defines what type of volume is required by the claim. Value of Filesystem is implied when not included in claim spec. |
| `spec.volumeName` | string |  | e.g. `<existing PersistentVolume>` | volumeName is the binding reference to the PersistentVolume backing this claim. |

| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.accessModes` | array of string |  |  | accessModes contains the desired access modes the volume should have. |
| `spec.dataSource` | object |  |  | TypedLocalObjectReference contains enough information to let you locate the typed referenced object inside the same namespace. |
| `spec.dataSource.apiGroup` | string |  |  | APIGroup is the group for the resource being referenced. If APIGroup is not specified, the specified Kind must be in the core API group. |
| `spec.dataSource.kind` | string | yes | default `` | Kind is the type of resource being referenced |
| `spec.dataSource.name` | string | yes | default `` | Name is the name of resource being referenced |
| `spec.dataSourceRef` | object |  |  | TypedObjectReference contains enough information to let you locate the typed referenced object |
| `spec.dataSourceRef.apiGroup` | string |  |  | APIGroup is the group for the resource being referenced. If APIGroup is not specified, the specified Kind must be in the core API group. |
| `spec.dataSourceRef.kind` | string | yes | default `` | Kind is the type of resource being referenced |
| `spec.dataSourceRef.name` | string | yes | default `` | Name is the name of resource being referenced |
| `spec.dataSourceRef.namespace` | string |  |  | Namespace is the namespace of resource being referenced Note that when a namespace is specified, a gateway.networking.k8s.io/ReferenceGrant object is required in the referent namespace to ... |
| `spec.resources` | object |  |  | VolumeResourceRequirements describes the storage resource requirements for a volume. |
| `spec.resources.limits` | object |  |  | Limits describes the maximum amount of compute resources allowed. |
| `spec.resources.requests` | object |  |  | Requests describes the minimum amount of compute resources required. |
| `spec.selector` | object |  |  | A label selector is a label query over a set of resources. The result of matchLabels and matchExpressions are ANDed. |
| `spec.selector.matchExpressions` | array of object |  |  | matchExpressions is a list of label selector requirements. The requirements are ANDed. |
| `spec.selector.matchExpressions[].key` | string | yes | default `` | key is the label key that the selector applies to. |
| `spec.selector.matchExpressions[].operator` | string | yes | default `` | operator represents a key's relationship to a set of values. Valid operators are In, NotIn, Exists and DoesNotExist. |
| `spec.selector.matchExpressions[].values` | array of string |  |  | values is an array of string values. If the operator is In or NotIn, the values array must be non-empty. If the operator is Exists or DoesNotExist, the values array must be empty. |
| `spec.selector.matchLabels` | object |  |  | matchLabels is a map of {key,value} pairs. |
| `spec.storageClassName` | string |  |  | storageClassName is the name of the StorageClass required by the claim. |
| `spec.volumeAttributesClassName` | string |  |  | volumeAttributesClassName may be used to set the VolumeAttributesClass used by this claim. |
| `spec.volumeMode` | string |  | `Block`, `Filesystem` | volumeMode defines what type of volume is required by the claim. Value of Filesystem is implied when not included in claim spec. |
| `spec.volumeName` | string |  |  | volumeName is the binding reference to the PersistentVolume backing this claim. |

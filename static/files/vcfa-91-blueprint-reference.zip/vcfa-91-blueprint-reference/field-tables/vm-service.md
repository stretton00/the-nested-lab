| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.clusterIp` | string |  |  | ClusterIP is the IP address of the service and is usually assigned randomly by the master. |
| `spec.externalName` | string |  |  | ExternalName is the external reference that kubedns or equivalent will return as a CNAME record for this service. No proxying will be involved. |
| `spec.loadBalancerIP` | string |  |  | LoadBalancer will get created with the IP specified in this field. |
| `spec.loadBalancerSourceRanges` | array of string |  |  | LoadBalancerSourceRanges is an array of IP addresses in the format of CIDRs, for example: 103.21.244.0/22 and 10.0.0.0/24. |
| `spec.ports` | array of object |  |  | Ports specifies a list of VirtualMachineServicePort to expose with this VirtualMachineService. Each of these ports will be an accessible network entry point to access this service by. |
| `spec.ports[].name` | string | yes |  | Name describes the name to be used to identify this VirtualMachineServicePort. |
| `spec.ports[].port` | integer | yes |  | Port describes the external port that will be exposed by the service. |
| `spec.ports[].protocol` | string | yes |  | Protocol describes the Layer 4 transport protocol for this port. Supports "TCP", "UDP", and "SCTP". |
| `spec.ports[].targetPort` | integer | yes |  | TargetPort describes the internal port open on a VirtualMachine that should be mapped to the external Port. |
| `spec.selector` | object |  |  | Selector specifies a map of key-value pairs, also known as a Label Selector, that is used to match this VirtualMachineService with the set of VirtualMachines that should back this VirtualMachineService. |
| `spec.type` | string | yes |  | Type specifies a desired VirtualMachineServiceType for this VirtualMachineService. Supported types are ClusterIP, LoadBalancer, ExternalName. |

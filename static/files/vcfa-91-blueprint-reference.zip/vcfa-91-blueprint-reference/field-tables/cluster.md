| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.availabilityGates` | array of object |  |  | availabilityGates specifies additional conditions to include when evaluating Cluster Available condition. |
| `spec.availabilityGates[].conditionType` | string | yes |  | conditionType refers to a condition with matching type in the Cluster's condition list. If the conditions doesn't exist, it will be treated as unknown. |
| `spec.availabilityGates[].polarity` | string |  | `Positive`, `Negative` | polarity of the conditionType specified in this availabilityGate. Valid values are Positive, Negative and omitted. When omitted, the default behaviour will be Positive. |
| `spec.clusterNetwork` | object |  |  | clusterNetwork represents the cluster network configuration. |
| `spec.clusterNetwork.apiServerPort` | integer |  |  | apiServerPort specifies the port the API Server should bind to. Defaults to 6443. |
| `spec.clusterNetwork.pods` | object |  |  | pods is the network ranges from which Pod networks are allocated. |
| `spec.clusterNetwork.pods.cidrBlocks` | array of string | yes |  | cidrBlocks is a list of CIDR blocks. |
| `spec.clusterNetwork.serviceDomain` | string |  |  | serviceDomain is the domain name for services. |
| `spec.clusterNetwork.services` | object |  |  | services is the network ranges from which service VIPs are allocated. |
| `spec.clusterNetwork.services.cidrBlocks` | array of string | yes |  | cidrBlocks is a list of CIDR blocks. |
| `spec.controlPlaneEndpoint` | object |  |  | controlPlaneEndpoint represents the endpoint used to communicate with the control plane. |
| `spec.controlPlaneEndpoint.host` | string |  |  | host is the hostname on which the API server is serving. |
| `spec.controlPlaneEndpoint.port` | integer |  |  | port is the port on which the API server is serving. |
| `spec.controlPlaneRef` | object |  |  | controlPlaneRef is an optional reference to a provider-specific resource that holds the details for provisioning the Control Plane for a Cluster. |
| `spec.controlPlaneRef.apiVersion` | string |  |  | API version of the referent. |
| `spec.controlPlaneRef.fieldPath` | string |  |  | If referring to a piece of an object instead of an entire object, this string should contain a valid JSON/Go field access statement, such as desiredState.manifest.containers[2]. |
| `spec.controlPlaneRef.kind` | string |  |  | Kind of the referent. |
| `spec.controlPlaneRef.name` | string |  |  | Name of the referent. |
| `spec.controlPlaneRef.namespace` | string |  |  | Namespace of the referent. |
| `spec.controlPlaneRef.resourceVersion` | string |  |  | Specific resourceVersion to which this reference is made, if any. |
| `spec.controlPlaneRef.uid` | string |  |  | UID of the referent. |
| `spec.infrastructureRef` | object |  |  | infrastructureRef is a reference to a provider-specific resource that holds the details for provisioning infrastructure for a cluster in said provider. |
| `spec.infrastructureRef.apiVersion` | string |  |  | API version of the referent. |
| `spec.infrastructureRef.fieldPath` | string |  |  | If referring to a piece of an object instead of an entire object, this string should contain a valid JSON/Go field access statement, such as desiredState.manifest.containers[2]. |
| `spec.infrastructureRef.kind` | string |  |  | Kind of the referent. |
| `spec.infrastructureRef.name` | string |  |  | Name of the referent. |
| `spec.infrastructureRef.namespace` | string |  |  | Namespace of the referent. |
| `spec.infrastructureRef.resourceVersion` | string |  |  | Specific resourceVersion to which this reference is made, if any. |
| `spec.infrastructureRef.uid` | string |  |  | UID of the referent. |
| `spec.paused` | boolean |  |  | paused can be used to prevent controllers from processing the Cluster and all its associated objects. |
| `spec.topology` | object |  |  | topology encapsulates the topology for the cluster. |
| `spec.topology.class` | string | yes |  | class is the name of the ClusterClass object to create the topology. |
| `spec.topology.classNamespace` | string |  |  | classNamespace is the namespace of the ClusterClass that should be used for the topology. If classNamespace is empty or not set, it is defaulted to the namespace of the Cluster object. |
| `spec.topology.controlPlane` | object |  |  | controlPlane describes the cluster control plane. |
| `spec.topology.controlPlane.machineHealthCheck` | object |  |  | machineHealthCheck allows to enable, disable and override the MachineHealthCheck configuration in the ClusterClass for this control plane. |
| `spec.topology.controlPlane.machineHealthCheck.enable` | boolean |  |  | enable controls if a MachineHealthCheck should be created for the target machines. If false: No MachineHealthCheck will be created. |
| `spec.topology.controlPlane.machineHealthCheck.maxUnhealthy` | int or string |  |  | maxUnhealthy specifies the maximum number of unhealthy machines allowed. Any further remediation is only allowed if at most "maxUnhealthy" machines selected by "selector" are not healthy. |
| `spec.topology.controlPlane.machineHealthCheck.nodeStartupTimeout` | string |  |  | nodeStartupTimeout allows to set the maximum time for MachineHealthCheck to consider a Machine unhealthy if a corresponding Node isn't associated through a `Spec.ProviderID` field. |
| `spec.topology.controlPlane.machineHealthCheck.remediationTemplate` | object |  |  | remediationTemplate is a reference to a remediation template provided by an infrastructure provider. |
| `spec.topology.controlPlane.machineHealthCheck.unhealthyConditions` | array of object |  |  | unhealthyConditions contains a list of the conditions that determine whether a node is considered unhealthy. The conditions are combined in a logical OR, i.e. |
| `spec.topology.controlPlane.machineHealthCheck.unhealthyRange` | string |  |  | unhealthyRange specifies the range of unhealthy machines allowed. |
| `spec.topology.controlPlane.metadata` | object |  |  | metadata is the metadata applied to the ControlPlane and the Machines of the ControlPlane if the ControlPlaneTemplate referenced by the ClusterClass is machine based. |
| `spec.topology.controlPlane.metadata.annotations` | object |  |  | annotations is an unstructured key value map stored with a resource that may be set by external tools to store and retrieve arbitrary metadata. |
| `spec.topology.controlPlane.metadata.labels` | object |  |  | labels is a map of string keys and values that can be used to organize and categorize (scope and select) objects. May match selectors of replication controllers and services. |
| `spec.topology.controlPlane.nodeDeletionTimeout` | string |  |  | nodeDeletionTimeout defines how long the controller will attempt to delete the Node that the Machine hosts after the Machine is marked for deletion. |
| `spec.topology.controlPlane.nodeDrainTimeout` | string |  |  | nodeDrainTimeout is the total amount of time that the controller will spend on draining a node. The default value is 0, meaning that the node can be drained without any time limitations. |
| `spec.topology.controlPlane.nodeVolumeDetachTimeout` | string |  |  | nodeVolumeDetachTimeout is the total amount of time that the controller will spend on waiting for all volumes to be detached. |
| `spec.topology.controlPlane.readinessGates` | array of object |  |  | readinessGates specifies additional conditions to include when evaluating Machine Ready condition. This field can be used e.g. |
| `spec.topology.controlPlane.readinessGates[].conditionType` | string | yes |  | conditionType refers to a condition with matching type in the Machine's condition list. If the conditions doesn't exist, it will be treated as unknown. |
| `spec.topology.controlPlane.readinessGates[].polarity` | string |  | `Positive`, `Negative` | polarity of the conditionType specified in this readinessGate. Valid values are Positive, Negative and omitted. When omitted, the default behaviour will be Positive. |
| `spec.topology.controlPlane.replicas` | integer |  |  | replicas is the number of control plane nodes. |
| `spec.topology.controlPlane.variables` | object |  |  | variables can be used to customize the ControlPlane through patches. |
| `spec.topology.controlPlane.variables.overrides` | array of object |  |  | overrides can be used to override Cluster level variables. |
| `spec.topology.rolloutAfter` | string |  |  | rolloutAfter performs a rollout of the entire cluster one component at a time, control plane first and then machine deployments. |
| `spec.topology.variables` | array of object |  |  | variables can be used to customize the Cluster through patches. They must comply to the corresponding VariableClasses defined in the ClusterClass. |
| `spec.topology.variables[].definitionFrom` | string |  |  | definitionFrom specifies where the definition of this Variable is from. Deprecated: This field is deprecated, must not be set anymore and is going to be removed in the next apiVersion. |
| `spec.topology.variables[].name` | string | yes |  | name of the variable. |
| `spec.topology.variables[].value` | any | yes |  | value of the variable. Note: the value will be validated against the schema of the corresponding ClusterClassVariable from the ClusterClass. |
| `spec.topology.version` | string | yes |  | version is the Kubernetes version of the cluster. |
| `spec.topology.workers` | object |  |  | workers encapsulates the different constructs that form the worker nodes for the cluster. |
| `spec.topology.workers.machineDeployments` | array of object |  |  | machineDeployments is a list of machine deployments in the cluster. |
| `spec.topology.workers.machineDeployments[].class` | string | yes |  | class is the name of the MachineDeploymentClass used to create the set of worker nodes. |
| `spec.topology.workers.machineDeployments[].failureDomain` | string |  |  | failureDomain is the failure domain the machines will be created in. Must match a key in the FailureDomains map stored on the cluster object. |
| `spec.topology.workers.machineDeployments[].machineHealthCheck` | object |  |  | machineHealthCheck allows to enable, disable and override the MachineHealthCheck configuration in the ClusterClass for this MachineDeployment. |
| `spec.topology.workers.machineDeployments[].metadata` | object |  |  | metadata is the metadata applied to the MachineDeployment and the machines of the MachineDeployment. At runtime this metadata is merged with the corresponding metadata from the ClusterClass. |
| `spec.topology.workers.machineDeployments[].minReadySeconds` | integer |  |  | minReadySeconds is the minimum number of seconds for which a newly created machine should be ready. Defaults to 0 (machine will be considered available as soon as it is ready) |
| `spec.topology.workers.machineDeployments[].name` | string | yes |  | name is the unique identifier for this MachineDeploymentTopology. The value is used with other unique identifiers to create a MachineDeployment's Name (e.g. |
| `spec.topology.workers.machineDeployments[].nodeDeletionTimeout` | string |  |  | nodeDeletionTimeout defines how long the controller will attempt to delete the Node that the Machine hosts after the Machine is marked for deletion. |
| `spec.topology.workers.machineDeployments[].nodeDrainTimeout` | string |  |  | nodeDrainTimeout is the total amount of time that the controller will spend on draining a node. The default value is 0, meaning that the node can be drained without any time limitations. |
| `spec.topology.workers.machineDeployments[].nodeVolumeDetachTimeout` | string |  |  | nodeVolumeDetachTimeout is the total amount of time that the controller will spend on waiting for all volumes to be detached. |
| `spec.topology.workers.machineDeployments[].readinessGates` | array of object |  |  | readinessGates specifies additional conditions to include when evaluating Machine Ready condition. This field can be used e.g. |
| `spec.topology.workers.machineDeployments[].replicas` | integer |  |  | replicas is the number of worker nodes belonging to this set. |
| `spec.topology.workers.machineDeployments[].strategy` | object |  |  | strategy is the deployment strategy to use to replace existing machines with new ones. |
| `spec.topology.workers.machineDeployments[].variables` | object |  |  | variables can be used to customize the MachineDeployment through patches. |
| `spec.topology.workers.machinePools` | array of object |  |  | machinePools is a list of machine pools in the cluster. |
| `spec.topology.workers.machinePools[].class` | string | yes |  | class is the name of the MachinePoolClass used to create the pool of worker nodes. |
| `spec.topology.workers.machinePools[].failureDomains` | array of string |  |  | failureDomains is the list of failure domains the machine pool will be created in. Must match a key in the FailureDomains map stored on the cluster object. |
| `spec.topology.workers.machinePools[].metadata` | object |  |  | metadata is the metadata applied to the MachinePool. At runtime this metadata is merged with the corresponding metadata from the ClusterClass. |
| `spec.topology.workers.machinePools[].minReadySeconds` | integer |  |  | minReadySeconds is the minimum number of seconds for which a newly created machine pool should be ready. Defaults to 0 (machine will be considered available as soon as it is ready) |
| `spec.topology.workers.machinePools[].name` | string | yes |  | name is the unique identifier for this MachinePoolTopology. The value is used with other unique identifiers to create a MachinePool's Name (e.g. |
| `spec.topology.workers.machinePools[].nodeDeletionTimeout` | string |  |  | nodeDeletionTimeout defines how long the controller will attempt to delete the Node that the MachinePool hosts after the MachinePool is marked for deletion. |
| `spec.topology.workers.machinePools[].nodeDrainTimeout` | string |  |  | nodeDrainTimeout is the total amount of time that the controller will spend on draining a node. The default value is 0, meaning that the node can be drained without any time limitations. |
| `spec.topology.workers.machinePools[].nodeVolumeDetachTimeout` | string |  |  | nodeVolumeDetachTimeout is the total amount of time that the controller will spend on waiting for all volumes to be detached. |
| `spec.topology.workers.machinePools[].replicas` | integer |  |  | replicas is the number of nodes belonging to this pool. |
| `spec.topology.workers.machinePools[].variables` | object |  |  | variables can be used to customize the MachinePool through patches. |

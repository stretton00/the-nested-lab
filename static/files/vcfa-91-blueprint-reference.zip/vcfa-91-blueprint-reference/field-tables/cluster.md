| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `spec.availabilityGates` | array of object |  | e.g. `[{conditionType: <condition type>, polarity: Positive}]` | availabilityGates specifies additional conditions to include when evaluating Cluster Available condition. |
| `spec.availabilityGates[].conditionType` | string | yes | e.g. `<condition type>` | conditionType refers to a condition with matching type in the Cluster's condition list. If the conditions doesn't exist, it will be treated as unknown. |
| `spec.availabilityGates[].polarity` | string |  | `Positive`, `Negative` | polarity of the conditionType specified in this availabilityGate. Valid values are Positive, Negative and omitted. When omitted, the default behaviour will be Positive. |
| `spec.clusterNetwork` | object |  | e.g. `{pods: {cidrBlocks: [192.168.156.0/20]}, serviceDomain: cluster.local}` | clusterNetwork represents the cluster network configuration. |
| `spec.clusterNetwork.apiServerPort` | integer |  | e.g. `6443` | apiServerPort specifies the port the API Server should bind to. Defaults to 6443. |
| `spec.clusterNetwork.pods` | object |  | e.g. `{cidrBlocks: [192.168.156.0/20]}` | pods is the network ranges from which Pod networks are allocated. |
| `spec.clusterNetwork.pods.cidrBlocks` | array of string | yes | e.g. `[192.168.156.0/20]` | cidrBlocks is a list of CIDR blocks. |
| `spec.clusterNetwork.serviceDomain` | string |  | e.g. `cluster.local` | serviceDomain is the domain name for services. |
| `spec.clusterNetwork.services` | object |  | e.g. `{cidrBlocks: [10.96.0.0/12]}` | services is the network ranges from which service VIPs are allocated. |
| `spec.clusterNetwork.services.cidrBlocks` | array of string | yes | e.g. `[10.96.0.0/12]` | cidrBlocks is a list of CIDR blocks. |
| `spec.controlPlaneEndpoint` | object |  | e.g. `{host: 192.168.144.40, port: 6443}` | controlPlaneEndpoint represents the endpoint used to communicate with the control plane. |
| `spec.controlPlaneEndpoint.host` | string |  | e.g. `192.168.144.40` | host is the hostname on which the API server is serving. |
| `spec.controlPlaneEndpoint.port` | integer |  | e.g. `6443` | port is the port on which the API server is serving. |
| `spec.controlPlaneRef` | object |  | e.g. `{kind: KubeadmControlPlane, name: lab-vks-cp}` | controlPlaneRef is an optional reference to a provider-specific resource that holds the details for provisioning the Control Plane for a Cluster. |
| `spec.controlPlaneRef.apiVersion` | string |  | e.g. `controlplane.cluster.x-k8s.io/v1beta1` | API version of the referent. |
| `spec.controlPlaneRef.fieldPath` | string |  | e.g. `(set by the platform)` | If referring to a piece of an object instead of an entire object, this string should contain a valid JSON/Go field access statement, such as desiredState.manifest.containers[2]. |
| `spec.controlPlaneRef.kind` | string |  | e.g. `KubeadmControlPlane` | Kind of the referent. |
| `spec.controlPlaneRef.name` | string |  | e.g. `lab-vks-cp` | Name of the referent. |
| `spec.controlPlaneRef.namespace` | string |  | e.g. `ns-lab` | Namespace of the referent. |
| `spec.controlPlaneRef.resourceVersion` | string |  | e.g. `(set by the platform)` | Specific resourceVersion to which this reference is made, if any. |
| `spec.controlPlaneRef.uid` | string |  | e.g. `(set by the platform)` | UID of the referent. |
| `spec.infrastructureRef` | object |  | e.g. `{kind: VSphereCluster, name: lab-vks}` | infrastructureRef is a reference to a provider-specific resource that holds the details for provisioning infrastructure for a cluster in said provider. |
| `spec.infrastructureRef.apiVersion` | string |  | e.g. `vmware.infrastructure.cluster.x-k8s.io/v1beta1` | API version of the referent. |
| `spec.infrastructureRef.fieldPath` | string |  | e.g. `(set by the platform)` | If referring to a piece of an object instead of an entire object, this string should contain a valid JSON/Go field access statement, such as desiredState.manifest.containers[2]. |
| `spec.infrastructureRef.kind` | string |  | e.g. `VSphereCluster` | Kind of the referent. |
| `spec.infrastructureRef.name` | string |  | e.g. `lab-vks` | Name of the referent. |
| `spec.infrastructureRef.namespace` | string |  | e.g. `ns-lab` | Namespace of the referent. |
| `spec.infrastructureRef.resourceVersion` | string |  | e.g. `(set by the platform)` | Specific resourceVersion to which this reference is made, if any. |
| `spec.infrastructureRef.uid` | string |  | e.g. `(set by the platform)` | UID of the referent. |
| `spec.paused` | boolean |  | e.g. `true` | paused can be used to prevent controllers from processing the Cluster and all its associated objects. |
| `spec.topology` | object |  | e.g. `{class: builtin-generic-v3.6.0, classNamespace: vmware-system-vks-public}` | topology encapsulates the topology for the cluster. |
| `spec.topology.class` | string | yes | e.g. `builtin-generic-v3.6.0` | class is the name of the ClusterClass object to create the topology. |
| `spec.topology.classNamespace` | string |  | e.g. `vmware-system-vks-public` | classNamespace is the namespace of the ClusterClass that should be used for the topology. If classNamespace is empty or not set, it is defaulted to the namespace of the Cluster object. |
| `spec.topology.controlPlane` | object |  | e.g. `{replicas: 1, machineHealthCheck: {maxUnhealthy: 40%, nodeStartupTimeout: 10m}}` | controlPlane describes the cluster control plane. |
| `spec.topology.controlPlane.machineHealthCheck` | object |  | e.g. `{maxUnhealthy: 40%, nodeStartupTimeout: 10m}` | machineHealthCheck allows to enable, disable and override the MachineHealthCheck configuration in the ClusterClass for this control plane. |
| `spec.topology.controlPlane.machineHealthCheck.enable` | boolean |  | e.g. `true` | enable controls if a MachineHealthCheck should be created for the target machines. If false: No MachineHealthCheck will be created. |
| `spec.topology.controlPlane.machineHealthCheck.maxUnhealthy` | int or string |  | e.g. `40%` | maxUnhealthy specifies the maximum number of unhealthy machines allowed. Any further remediation is only allowed if at most "maxUnhealthy" machines selected by "selector" are not healthy. |
| `spec.topology.controlPlane.machineHealthCheck.nodeStartupTimeout` | string |  | e.g. `10m` | nodeStartupTimeout allows to set the maximum time for MachineHealthCheck to consider a Machine unhealthy if a corresponding Node isn't associated through a `Spec.ProviderID` field. |
| `spec.topology.controlPlane.machineHealthCheck.remediationTemplate` | object |  | e.g. `{apiVersion: <group>/<version>, kind: <remediation template kind>, name: <name>}` | remediationTemplate is a reference to a remediation template provided by an infrastructure provider. |
| `spec.topology.controlPlane.machineHealthCheck.unhealthyConditions` | array of object |  | e.g. `[{type: Ready, status: Unknown, timeout: 300s}]` | unhealthyConditions contains a list of the conditions that determine whether a node is considered unhealthy. The conditions are combined in a logical OR, i.e. |
| `spec.topology.controlPlane.machineHealthCheck.unhealthyRange` | string |  | e.g. `'[1-3]'` | unhealthyRange specifies the range of unhealthy machines allowed. |
| `spec.topology.controlPlane.metadata` | object |  | e.g. `{annotations: {owner: team-a}, labels: {app: web}}` | metadata is the metadata applied to the ControlPlane and the Machines of the ControlPlane if the ControlPlaneTemplate referenced by the ClusterClass is machine based. |
| `spec.topology.controlPlane.metadata.annotations` | object |  | e.g. `{owner: team-a}` | annotations is an unstructured key value map stored with a resource that may be set by external tools to store and retrieve arbitrary metadata. |
| `spec.topology.controlPlane.metadata.labels` | object |  | e.g. `{app: web}` | labels is a map of string keys and values that can be used to organize and categorize (scope and select) objects. May match selectors of replication controllers and services. |
| `spec.topology.controlPlane.nodeDeletionTimeout` | string |  | e.g. `10m` | nodeDeletionTimeout defines how long the controller will attempt to delete the Node that the Machine hosts after the Machine is marked for deletion. |
| `spec.topology.controlPlane.nodeDrainTimeout` | string |  | e.g. `10m` | nodeDrainTimeout is the total amount of time that the controller will spend on draining a node. The default value is 0, meaning that the node can be drained without any time limitations. |
| `spec.topology.controlPlane.nodeVolumeDetachTimeout` | string |  | e.g. `10m` | nodeVolumeDetachTimeout is the total amount of time that the controller will spend on waiting for all volumes to be detached. |
| `spec.topology.controlPlane.readinessGates` | array of object |  | e.g. `[{conditionType: <condition type>, polarity: Positive}]` | readinessGates specifies additional conditions to include when evaluating Machine Ready condition. This field can be used e.g. |
| `spec.topology.controlPlane.readinessGates[].conditionType` | string | yes | e.g. `<condition type>` | conditionType refers to a condition with matching type in the Machine's condition list. If the conditions doesn't exist, it will be treated as unknown. |
| `spec.topology.controlPlane.readinessGates[].polarity` | string |  | `Positive`, `Negative` | polarity of the conditionType specified in this readinessGate. Valid values are Positive, Negative and omitted. When omitted, the default behaviour will be Positive. |
| `spec.topology.controlPlane.replicas` | integer |  | e.g. `1` | replicas is the number of control plane nodes. |
| `spec.topology.controlPlane.variables` | object |  | e.g. `{overrides: [{name: vmClass, value: best-effort-medium}]}` | variables can be used to customize the ControlPlane through patches. |
| `spec.topology.controlPlane.variables.overrides` | array of object |  | e.g. `[{name: vmClass, value: best-effort-medium}]` | overrides can be used to override Cluster level variables. |
| `spec.topology.rolloutAfter` | string |  | e.g. `2026-10-01T22:00:00Z` | rolloutAfter performs a rollout of the entire cluster one component at a time, control plane first and then machine deployments. |
| `spec.topology.variables` | array of object |  | e.g. `[{name: vmClass, value: best-effort-small}]` | variables can be used to customize the Cluster through patches. They must comply to the corresponding VariableClasses defined in the ClusterClass. |
| `spec.topology.variables[].definitionFrom` | string |  | e.g. `<patch name>` | definitionFrom specifies where the definition of this Variable is from. Deprecated: This field is deprecated, must not be set anymore and is going to be removed in the next apiVersion. |
| `spec.topology.variables[].name` | string | yes | e.g. `vmClass` | name of the variable. |
| `spec.topology.variables[].value` | any | yes | e.g. `best-effort-small` | value of the variable. Note: the value will be validated against the schema of the corresponding ClusterClassVariable from the ClusterClass. |
| `spec.topology.version` | string | yes | e.g. `v1.35.5+vmware.1-vkr.1` | version is the Kubernetes version of the cluster. |
| `spec.topology.workers` | object |  | e.g. `{machineDeployments: [{name: np-1, class: node-pool}], machinePools: [{name: mp-1, ...}]}` | workers encapsulates the different constructs that form the worker nodes for the cluster. |
| `spec.topology.workers.machineDeployments` | array of object |  | e.g. `[{name: np-1, class: node-pool}]` | machineDeployments is a list of machine deployments in the cluster. |
| `spec.topology.workers.machineDeployments[].class` | string | yes | e.g. `node-pool` | class is the name of the MachineDeploymentClass used to create the set of worker nodes. |
| `spec.topology.workers.machineDeployments[].failureDomain` | string |  | e.g. `domain-c9` | failureDomain is the failure domain the machines will be created in. Must match a key in the FailureDomains map stored on the cluster object. |
| `spec.topology.workers.machineDeployments[].machineHealthCheck` | object |  | e.g. `{enable: true}` | machineHealthCheck allows to enable, disable and override the MachineHealthCheck configuration in the ClusterClass for this MachineDeployment. |
| `spec.topology.workers.machineDeployments[].metadata` | object |  | e.g. `{labels: {pool: np-1}}` | metadata is the metadata applied to the MachineDeployment and the machines of the MachineDeployment. At runtime this metadata is merged with the corresponding metadata from the ClusterClass. |
| `spec.topology.workers.machineDeployments[].minReadySeconds` | integer |  | e.g. `10` | minReadySeconds is the minimum number of seconds for which a newly created machine should be ready. Defaults to 0 (machine will be considered available as soon as it is ready) |
| `spec.topology.workers.machineDeployments[].name` | string | yes | e.g. `np-1` | name is the unique identifier for this MachineDeploymentTopology. The value is used with other unique identifiers to create a MachineDeployment's Name (e.g. |
| `spec.topology.workers.machineDeployments[].nodeDeletionTimeout` | string |  | e.g. `10m` | nodeDeletionTimeout defines how long the controller will attempt to delete the Node that the Machine hosts after the Machine is marked for deletion. |
| `spec.topology.workers.machineDeployments[].nodeDrainTimeout` | string |  | e.g. `10m` | nodeDrainTimeout is the total amount of time that the controller will spend on draining a node. The default value is 0, meaning that the node can be drained without any time limitations. |
| `spec.topology.workers.machineDeployments[].nodeVolumeDetachTimeout` | string |  | e.g. `10m` | nodeVolumeDetachTimeout is the total amount of time that the controller will spend on waiting for all volumes to be detached. |
| `spec.topology.workers.machineDeployments[].readinessGates` | array of object |  | e.g. `[{conditionType: <condition type>}]` | readinessGates specifies additional conditions to include when evaluating Machine Ready condition. This field can be used e.g. |
| `spec.topology.workers.machineDeployments[].replicas` | integer |  | e.g. `1` | replicas is the number of worker nodes belonging to this set. |
| `spec.topology.workers.machineDeployments[].strategy` | object |  | e.g. `{type: RollingUpdate, rollingUpdate: {maxSurge: 1}}` | strategy is the deployment strategy to use to replace existing machines with new ones. |
| `spec.topology.workers.machineDeployments[].variables` | object |  | e.g. `{overrides: [{name: vmClass, value: best-effort-large}]}` | variables can be used to customize the MachineDeployment through patches. |
| `spec.topology.workers.machinePools` | array of object |  | e.g. `[{name: mp-1, class: <machine pool class>}]` | machinePools is a list of machine pools in the cluster. |
| `spec.topology.workers.machinePools[].class` | string | yes | e.g. `<machine pool class>` | class is the name of the MachinePoolClass used to create the pool of worker nodes. |
| `spec.topology.workers.machinePools[].failureDomains` | array of string |  | e.g. `[domain-c9]` | failureDomains is the list of failure domains the machine pool will be created in. Must match a key in the FailureDomains map stored on the cluster object. |
| `spec.topology.workers.machinePools[].metadata` | object |  | e.g. `{labels: {pool: mp-1}}` | metadata is the metadata applied to the MachinePool. At runtime this metadata is merged with the corresponding metadata from the ClusterClass. |
| `spec.topology.workers.machinePools[].minReadySeconds` | integer |  | e.g. `10` | minReadySeconds is the minimum number of seconds for which a newly created machine pool should be ready. Defaults to 0 (machine will be considered available as soon as it is ready) |
| `spec.topology.workers.machinePools[].name` | string | yes | e.g. `mp-1` | name is the unique identifier for this MachinePoolTopology. The value is used with other unique identifiers to create a MachinePool's Name (e.g. |
| `spec.topology.workers.machinePools[].nodeDeletionTimeout` | string |  | e.g. `10m` | nodeDeletionTimeout defines how long the controller will attempt to delete the Node that the MachinePool hosts after the MachinePool is marked for deletion. |
| `spec.topology.workers.machinePools[].nodeDrainTimeout` | string |  | e.g. `10m` | nodeDrainTimeout is the total amount of time that the controller will spend on draining a node. The default value is 0, meaning that the node can be drained without any time limitations. |
| `spec.topology.workers.machinePools[].nodeVolumeDetachTimeout` | string |  | e.g. `10m` | nodeVolumeDetachTimeout is the total amount of time that the controller will spend on waiting for all volumes to be detached. |
| `spec.topology.workers.machinePools[].replicas` | integer |  | e.g. `2` | replicas is the number of nodes belonging to this pool. |
| `spec.topology.workers.machinePools[].variables` | object |  | e.g. `{overrides: [{name: vmClass, value: best-effort-large}]}` | variables can be used to customize the MachinePool through patches. |

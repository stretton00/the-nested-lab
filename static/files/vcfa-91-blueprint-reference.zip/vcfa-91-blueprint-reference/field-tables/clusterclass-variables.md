| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `bootstrapAddons` | object |  |  | BootstrapAddons defines Addons to be installed on Cluster during bootstrapping. Only supported with Kubernetes 1.35 and above. |
| `bootstrapAddons.cniRef` | object | yes |  | CNI Addon to instantiate for Cluster. Used to select CNI rather than ClusterBootstrap spec.CNI field. Compatible Addon/AddonRelease must exist. |
| `bootstrapAddons.cniRef.name` | string | yes |  | Name of the Addon being referenced. |
| `bootstrapAddons.cniRef.namespace` | string |  |  | Namespace of the addon being referenced. If not specified, will use the default public namespace defined by the addon manager. |
| `kubeAPIServerFQDNs` | array of string |  |  | Deprecated: This variable is deprecated. Use kubernetes.endpointFQDNs instead. This variable will be removed in a future release. |
| `kubernetes` | object |  |  | Kubernetes configures cluster-wide settings for the Kubernetes cluster, typically applied to the control plane. Supported scopes: cluster, controlPlane, workers |
| `kubernetes.apiServerConfiguration` | object |  |  | APIServerConfiguration contains configuration options for the Kubernetes API server. |
| `kubernetes.apiServerConfiguration.logs` | object |  |  | Logging configures the logging options for the API server, including log levels, formats, and output destinations. Refer to the Kubernetes component-base logs options for more information. |
| `kubernetes.apiServerConfiguration.logs.flushFrequency` | string |  |  | FlushFrequency is the maximum time between log flushes. If specified as a string, it's parsed as a duration (e.g., "1s"). |
| `kubernetes.apiServerConfiguration.logs.format` | string |  | `text`, `json` | Format specifies the structure of log messages. Supported values are "text" (default) and "json". Corresponds to --logging-format flag. |
| `kubernetes.apiServerConfiguration.logs.verbosity` | integer |  |  | Verbosity is the threshold that determines which log messages are logged. Default is zero which logs only the most important messages. |
| `kubernetes.apiServerConfiguration.maxMutatingRequestsInFlight` | integer |  |  | MaxMutatingRequestsInFlight is the maximum number of parallel mutating requests. Every further request has to wait. |
| `kubernetes.apiServerConfiguration.maxRequestsInFlight` | integer |  |  | MaxRequestsInFlight is the maximum number of parallel non-long-running requests. Every further request has to wait. |
| `kubernetes.apiServerConfiguration.profiling` | boolean |  |  | Profiling enables profiling via web interface host:port/debug/pprof/ Default: false |
| `kubernetes.apiServerConfiguration.requestTimeout` | string |  |  | RequestTimeout is the duration after which all non-long-running requests will be timed out. Corresponds to the --request-timeout flag. |
| `kubernetes.certificateRotation` | object |  |  | CertificateRotation configures options for the automatic rotation of control plane certificates which have a default validity of 12 months. |
| `kubernetes.certificateRotation.enabled` | boolean |  | default `true` | Enabled controls enablement of auto certificate rotation |
| `kubernetes.certificateRotation.renewalDaysBeforeExpiry` | integer |  | default `90` | RenewalDaysBeforeExpiry states the number of days before certificate expiry to initiate the renewal of certificates. |
| `kubernetes.endpointFQDNs` | array of string |  |  | EndpointFQDNs Configure FQDN aliases for the control plane endpoint for example to allow users to connect to the cluster using https://k8s.prod.example.com/ |
| `kubernetes.etcdConfiguration` | object |  |  | EtcdConfiguration contains configuration options for the etcd database used by Kubernetes. These settings control etcd behavior including database size limits and performance tuning. |
| `kubernetes.etcdConfiguration.maximumDBSizeGiB` | integer | yes |  | MaximumDBSizeGiB specifies the maximum size of the etcd database in GiB. This value is used to set --quota-backend-bytes for etcd. |
| `kubernetes.kubeControllerManagerConfiguration` | object |  |  | KubeControllerManagerConfiguration contains configuration options for the kube-controller-manager. Supported scopes: cluster, controlPlane |
| `kubernetes.kubeControllerManagerConfiguration.terminatedPodGCThreshold` | integer |  |  | TerminatedPodGCThreshold is the number of terminated pods that can exist before the terminated pod garbage collector starts deleting terminated pods. |
| `kubernetes.kubeletConfiguration` | object |  |  | KubeletConfiguration contains configuration options for the kubelet running on worker nodes. |
| `kubernetes.kubeletConfiguration.allowedUnsafeSysctls` | array of string |  |  | AllowedUnsafeSysctls is a comma separated allowlist of unsafe sysctls or sysctl patterns (ending in `*`). All safe sysctls are enabled by default. |
| `kubernetes.kubeletConfiguration.containerLogMaxFiles` | integer |  |  | ContainerLogMaxFiles is the maximum number of container log files that can be present for a container. Default: 5 |
| `kubernetes.kubeletConfiguration.containerLogMaxSizeMiB` | integer |  |  | ContainerLogMaxSize defines the maximum size of the container log file before it is rotated in MiB. |
| `kubernetes.kubeletConfiguration.eventBurst` | integer |  |  | EventBurst is the maximum size of a burst of event creations, temporarily allows event creations to burst to this number, while still not exceeding eventRecordQPS. |
| `kubernetes.kubeletConfiguration.eventRecordQPS` | integer |  |  | EventRecordQPS is the maximum event creations per second. If 0, there is no limit enforced. Corresponds to --event-qps kubelet flag. |
| `kubernetes.kubeletConfiguration.healthzBindAddress` | string |  |  | HealthzBindAddress is the IP address for the healthz server to serve on. Default: "127.0.0.1" |
| `kubernetes.kubeletConfiguration.imageGCHighThresholdPercent` | integer |  |  | ImageGCHighThresholdPercent is the percent of disk usage after which image garbage collection is always run. The percent is calculated as this field value out of 100. |
| `kubernetes.kubeletConfiguration.imageGCLowThresholdPercent` | integer |  |  | ImageGCLowThresholdPercent is the percent of disk usage before which image garbage collection is never run. Lowest disk usage to garbage collect to. |
| `kubernetes.kubeletConfiguration.imageMaximumGCAge` | string |  |  | ImageMaximumGCAge is the maximum age an image can be unused before it is garbage collected. |
| `kubernetes.kubeletConfiguration.imageMinimumGCAge` | string |  |  | ImageMinimumGCAge is the minimum age for an unused image before it is garbage collected. Default: "2m" |
| `kubernetes.kubeletConfiguration.imagePullCredentialsVerificationPolicy` | string |  | `NeverVerify`, `NeverVerifyPreloadedImages`, `NeverVerifyAllowlistedImages`, `AlwaysVerify` | ImagePullCredentialsVerificationPolicy determines how credentials should be verified when pod requests an image that is already present on the node. |
| `kubernetes.kubeletConfiguration.logging` | object |  |  | Logging specifies the logging configuration options for the kubelet. This controls log levels, formats, and output destinations for kubelet logs. |
| `kubernetes.kubeletConfiguration.logging.flushFrequency` | string |  |  | FlushFrequency is the maximum time between log flushes. If specified as a string, it's parsed as a duration (e.g., "1s"). |
| `kubernetes.kubeletConfiguration.logging.format` | string |  | `text`, `json` | Format specifies the structure of log messages. Supported values are "text" (default) and "json". Corresponds to --logging-format flag. |
| `kubernetes.kubeletConfiguration.logging.verbosity` | integer |  |  | Verbosity is the threshold that determines which log messages are logged. Default is zero which logs only the most important messages. |
| `kubernetes.kubeletConfiguration.maxParallelImagePulls` | integer |  |  | MaxParallelImagePulls sets the maximum number of image pulls in parallel. This field is only used when SerializeImagePulls is false. |
| `kubernetes.kubeletConfiguration.maxPods` | integer |  |  | MaxPods is the number of pods that can run on this Kubelet. Default: 110 NOTE: By default, the maximum allowed value is 250. |
| `kubernetes.kubeletConfiguration.podPidsLimit` | integer |  |  | PodPidsLimit is the maximum number of PIDs in any pod. Use Kubelet default (-1) when omitted. Default: nil |
| `kubernetes.kubeletConfiguration.preloadedImagesVerificationAllowlist` | array of string |  |  | PreloadedImagesVerificationAllowlist specifies a list of images that are exempted from credential reverification for the "NeverVerifyAllowlistedImages" `imagePullCredentialsVerificationPolicy`. |
| `kubernetes.kubeletConfiguration.registryBurst` | integer |  |  | RegistryBurst is the maximum size of bursty pulls, temporarily allows pulls to burst to this number, while still not exceeding registryPullQPS. |
| `kubernetes.kubeletConfiguration.registryPullQPS` | integer |  |  | RegistryPullQPS is the limit of registry pulls per second. Set to 0 for no limit. Default: 5 |
| `kubernetes.kubeletConfiguration.serializeImagePulls` | boolean |  |  | SerializeImagePulls when enabled, tells the Kubelet to pull images one at a time. Default: true |
| `kubernetes.kubeletConfiguration.streamingConnectionIdleTimeout` | string |  |  | StreamingConnectionIdleTimeout is the maximum time a streaming connection can be idle before the connection is automatically closed. |
| `kubernetes.security` | object |  |  | Security configures Kubernetes specific security settings. |
| `kubernetes.security.podSecurityStandard` | object |  |  | PodSecurityStandard configures the PodSecurityStandard settings for the cluster. |
| `kubernetes.security.podSecurityStandard.audit` | string |  | ``, `privileged`, `baseline`, `restricted` | Audit sets the level for the audit PodSecurityConfiguration mode. Policy violations trigger an audit annotation, but are otherwise allowed One of "", privileged, baseline, restricted. |
| `kubernetes.security.podSecurityStandard.auditVersion` | string |  |  | AuditVersion can be used to pin the policy to the version that shipped with a given Kubernetes minor version (e.g. v1.31) when in audit mode. |
| `kubernetes.security.podSecurityStandard.deactivated` | boolean |  | default `false` | Deactivated disables the patches for Pod Security Standard via AdmissionConfiguration. |
| `kubernetes.security.podSecurityStandard.enforce` | string |  | ``, `privileged`, `baseline`, `restricted` | Enforce sets the level for the enforce PodSecurityConfiguration mode. Policy violations cause the pod to be rejected. |
| `kubernetes.security.podSecurityStandard.enforceVersion` | string |  |  | EnforceVersion can be used to pin the policy to the version that shipped with a given Kubernetes minor version (e.g. |
| `kubernetes.security.podSecurityStandard.exemptions` | object |  |  | Exemptions can be statically configured based on (requesting) user, RuntimeClass, or namespace. A request meeting exemption criteria is ignored by the admission plugin. |
| `kubernetes.security.podSecurityStandard.warn` | string |  | ``, `privileged`, `baseline`, `restricted` | Warn sets the level for the warn PodSecurityConfiguration mode. Policy violations trigger a user-facing warning, but are otherwise allowed. |
| `kubernetes.security.podSecurityStandard.warnVersion` | string |  |  | WarnVersion can be used to pin the policy to the version that shipped with a given Kubernetes minor version (e.g. v1.31) when in warn mode. |
| `kubernetes.security.resourceQuotaConfiguration` | object |  |  | ResourceQuotaConfiguration configures the ResourceQuota admission control settings for the cluster. |
| `kubernetes.security.resourceQuotaConfiguration.enabled` | boolean |  | default `false` | Enabled enables the patches for ResourceQuotaConfiguration via AdmissionConfiguration. |
| `networks` | object |  |  | Networks defines the network configuration for the cluster |
| `networks.interfaces` | object |  |  | Interfaces describes one primary (eth0) and zero or more secondary interfaces attached to Node virtual machine. |
| `networks.interfaces.primary` | object |  |  | Primary is the primary network interface which is used to connect the Kubernetes primary network for Load balancer, Service discovery, Pod traffic and management traffic etc. |
| `networks.interfaces.primary.mtu` | integer |  |  | MTU is the Maximum Transmission Unit size in bytes. |
| `networks.interfaces.primary.network` | object | yes |  | Network is the name of the network resource to which this interface is connected. |
| `networks.interfaces.primary.routes` | array of object |  |  | Routes is a list of optional, static routes. |
| `networks.interfaces.secondary` | array of object |  |  | Secondary network is supported with network provider NSX-VPC and vsphere-network. |
| `networks.interfaces.secondary[].mtu` | integer |  |  | MTU is the Maximum Transmission Unit size in bytes. |
| `networks.interfaces.secondary[].name` | string | yes |  | Name describes the unique name of this network interface, used to distinguish it from other network interfaces attached to node Virtual Machine. |
| `networks.interfaces.secondary[].network` | object | yes |  | Network is the name of the network resource to which this interface is connected. |
| `networks.interfaces.secondary[].routes` | array of object |  |  | Routes is a list of optional, static routes. |
| `node` | object |  |  | Node configures Kubernetes node specific settings. Supported scopes: cluster, controlPlane, workers |
| `node.firewall` | object |  |  | Firewall specifies the firewall configuration that should be created on the node to allow specific kinds of traffic. |
| `node.firewall.inboundRules` | array of object | yes |  | InboundRules is a list of firewall rules that will be configured on each node to allow or deny specific kinds of traffic. |
| `node.firewall.inboundRules[].fromPort` | integer |  |  | FromPort is the low end (inclusive) of the port range that this rule applies to. |
| `node.firewall.inboundRules[].protocol` | int or string | yes |  | Protocol is the type of traffic that this rule applies to. Allowed protocols include "tcp", "udp", "icmp", or an any valid IANA protocol number. |
| `node.firewall.inboundRules[].source` | string |  |  | Source is the CIDR range of the originating traffic that this rule applies to. If unset, the rule will apply to any source network. |
| `node.firewall.inboundRules[].toPort` | integer |  |  | ToPort is the high end (inclusive) of the port range that this rule applies to. |
| `node.labels` | object |  |  | Labels is a list of user defined name-value pairs |
| `node.taints` | array of object |  |  | Taints specifies the taints the Node API object should be registered with. If this field is unset, i.e. nil, it will be defaulted with a control-plane taint for control-plane nodes. |
| `node.taints[].effect` | string | yes | `NoSchedule`, `PreferNoSchedule`, `NoExecute` | Effect of the taint on pods that do not tolerate the taint. Valid effects are NoSchedule, PreferNoSchedule and NoExecute. |
| `node.taints[].key` | string | yes |  | Key is the taint key to be applied to a node. |
| `node.taints[].value` | string | yes |  | Value is the taint value corresponding to the taint key. |
| `osConfiguration` | object |  |  | OSConfiguration configures the system settings of nodes that are independent of Kubernetes. Supported scopes: cluster, controlPlane, workers |
| `osConfiguration.directoryJoin` | object |  |  | DirectoryJoin configures the node to join a Windows Active Directory. Only supported on Windows at present. |
| `osConfiguration.directoryJoin.credentialSecretRef` | string | yes |  | CredentialSecretRef is the name of the secret containing Active Directory join credentials. |
| `osConfiguration.directoryJoin.domain` | string | yes |  | Domain is the FQDN of the Active Directory Kerberos domain to join. |
| `osConfiguration.directoryJoin.gmsaControlSecurityGroupDN` | string |  |  | GMSAControlSecurityGroupDN is an optional Windows Active Directory security group that has permissions to access the password of the Group Managed Service Accounts. |
| `osConfiguration.directoryJoin.organizationalUnitDN` | string |  |  | OrganizationalUnitDN is an optional organizational unit where the node will be added to in Active Directory. The value will be validated according to https://tools.ietf.org/html/rfc4514 |
| `osConfiguration.fips` | object |  |  | FIPS configures FIPS related settings for the Kubernetes cluster to run in FIPS mode. Supported scopes: cluster |
| `osConfiguration.fips.enabled` | boolean |  | default `false` | Enable specifies whether FIPS settings are enabled and enforced on the node |
| `osConfiguration.grub` | object |  |  | GRUB configures GRUB Boot Loader. |
| `osConfiguration.grub.password` | object |  |  | Password configures the password protection for GRUB Boot Loader (Only applicable on Linux). |
| `osConfiguration.grub.password.enabled` | boolean |  | default `false` | Enabled defines if the GRUB Boot Loader must be protected with a password |
| `osConfiguration.grub.password.secretRef` | object |  |  | SecretRef is the name of the secret containing the password to protect GRUB Key is the data.key field within the secret containing the password value. |
| `osConfiguration.grub.password.user` | string |  |  | User specifies the username to use for GRUB password protection. |
| `osConfiguration.ntp` | object |  |  | NTP sets the time servers that will be used by nodes in the cluster. By default, NTP servers are inherited from vCenter. |
| `osConfiguration.ntp.servers` | array of string | yes |  | NTP sets the time servers that will be used by nodes in this cluster. By default, NTP servers are inherited from vCenter. |
| `osConfiguration.securityContext` | object |  |  | SecurityContext holds security configurations that will be applied to node. |
| `osConfiguration.securityContext.appArmor` | object |  |  | AppArmor configures the appArmor profiles of the node. Supported scopes: cluster, controlPlane, workers Only supported on Ubuntu and Photon nodes. |
| `osConfiguration.securityContext.appArmor.profiles` | array of object | yes |  | Profiles is a list of appArmor profiles to be added to the node. |
| `osConfiguration.sshd` | object |  |  | SSHD configures the sshd config of the node. |
| `osConfiguration.sshd.banner` | string |  |  | Banner specifies the login message used for sending a legal warning message before authentication |
| `osConfiguration.systemProxy` | object |  |  | SystemProxy configures parameters that reference a proxy server for outbound cluster connections. |
| `osConfiguration.systemProxy.http` | string | yes |  | HTTP is the proxy server to be used for all http connections. This should be a hostname or dotted numerical IP address. |
| `osConfiguration.systemProxy.https` | string | yes |  | HTTPS configures the proxy server to be used for all https connections. This should be a hostname or dotted numerical IP address. |
| `osConfiguration.systemProxy.noProxy` | array of string | yes |  | NoProxy configures the list of hostnames and CIDR ranges that should be reached without the configured proxy servers. |
| `osConfiguration.trust` | object |  |  | Trust configures system-wide certificate trust for nodes |
| `osConfiguration.trust.additionalTrustedCAs` | array of object | yes |  | AdditionalTrustedCAs is a list of additional CAs to be added to the system trust store of nodes. |
| `osConfiguration.trust.additionalTrustedCAs[].caCert` | object | yes |  | SecretContent configures a reference to or content of secret data. |
| `osConfiguration.tuned` | object |  |  | TuneD injects TuneD profiles and activate specified profile on Linux nodes. Only supported on Linux. |
| `osConfiguration.tuned.active` | array of string | yes |  | Active is a list of tuned profile name will be activated on node. |
| `osConfiguration.tuned.profiles` | object |  |  | Profiles is a map of tuned profiles will be injected on node. Key is the desired tuned profile name, value is the TunedProfile CR reference which contains the profile content. |
| `osConfiguration.ubuntuPro` | object |  |  | UbuntuPro configures the Ubuntu Pro subscription of the node. Only supported on Ubuntu. |
| `osConfiguration.ubuntuPro.services` | array of string |  |  | Services specifies the Ubuntu Pro services to be enabled. |
| `osConfiguration.ubuntuPro.settings` | array of object |  |  | Settings specifies the Ubuntu Pro client (ubuntu-advantage-tools) settings to be configured. |
| `osConfiguration.ubuntuPro.settings[].key` | string | yes |  |  |
| `osConfiguration.ubuntuPro.settings[].value` | string | yes |  |  |
| `osConfiguration.ubuntuPro.tokenSecretRef` | string | yes |  | TokenSecretRef is the name of the secret containing a valid Ubuntu Pro Subscription token. The secret must have a key token with the content of a valid token. |
| `osConfiguration.user` | object |  |  | User is an administrative user that will be created on all nodes. If not set, this is defaulted to "vmware-system-user". |
| `osConfiguration.user.password` | object |  |  | Password configures the password policy such as password max age and renewal settings. |
| `osConfiguration.user.password.renewalDaysBeforeExpiry` | integer |  |  | RenewalDaysBeforeExpiry configures the days to renew the password before it gets expired. |
| `osConfiguration.user.passwordSecret` | object |  |  | Key is the data.key field within the secret containing the password value. If not specified, the secret will be automatically generated as <cluster name>-ssh-password. |
| `osConfiguration.user.passwordSecret.key` | string | yes |  | Key is the data.key field within the secret containing the password value. For Linux, this must be the hashed value that should be inserted into /etc/shadow. |
| `osConfiguration.user.passwordSecret.name` | string | yes |  | Name is the name of the secret containing the password for the administrative account. |
| `osConfiguration.user.requirePasswordOnSudo` | boolean |  |  | RequirePasswordOnSudo configures whether password re-authentication is required on sudo. |
| `osConfiguration.user.sshAuthorizedKey` | string |  |  | The string of the SSH public key that is to be used for the administrative account. The public key must be of any FIPS-140 approved algorithm. |
| `osConfiguration.user.user` | string | yes |  | Name is the name of the user to be created. By default, this is vmware-system-user. |
| `resourceConfiguration` | object |  |  | ResourceConfiguration configures kubelet resource options. Currently, only CPU and memory reservations are supported. |
| `resourceConfiguration.systemReserved` | object |  |  | SystemReserved defines the system reserved CPU and memory reservations. |
| `resourceConfiguration.systemReserved.automatic` | boolean |  | default `true` | Automatic controls the automatic calculation of system reserved resources. |
| `resourceConfiguration.systemReserved.cpu` | int or string |  |  | CPU describes the number of CPU cores reserved for system processes. |
| `resourceConfiguration.systemReserved.memory` | int or string |  |  | Memory describes the memory resources reserved for system processes. |
| `storageClass` | string | yes |  | StorageClass sets the StorageClass that will be used to create node root volumes. |
| `vmClass` | string | yes |  | VMClass sets the VMClass that will be used to create nodes. Supported scopes: cluster, controlPlane, workers |
| `volumes` | array of object |  |  | Volumes configures additional disks to be attached to node virtual machines. Supported scopes: cluster, controlPlane, workers |
| `volumes[].capacity` | string | yes |  | Capacity defines the storage capacity of the volume. |
| `volumes[].mountPath` | string | yes |  | MountPath defines the mount path for the volume. |
| `volumes[].name` | string | yes |  | Name defines the name of the volume. |
| `volumes[].storageClass` | string |  |  | StorageClass defines the Storage class to use for the volume. |
| `vsphereOptions` | object |  |  | VSphereOptions configures vSphere specific options related to nodes Supported scopes: cluster, controlPlane, workers |
| `vsphereOptions.persistentVolumes` | object |  |  | PersistentVolumes configures what is available for PVCs to be used in the cluster. |
| `vsphereOptions.persistentVolumes.availableStorageClasses` | array of string |  |  | AvailableStorageClasses lists the storage classes that can be used in the cluster. |
| `vsphereOptions.persistentVolumes.availableVolumeSnapshotClasses` | array of string |  |  | AvailableVolumeSnapshotClasses lists the volume snapshot classes that can be used in the cluster. |
| `vsphereOptions.persistentVolumes.customizableStorageClassAnnotations` | array of string |  |  | CustomizableStorageClassAnnotations is a list of annotation keys set on the storage classes within the cluster which can be customized by the user. |
| `vsphereOptions.persistentVolumes.customizableStorageClassLabels` | array of string |  |  | CustomizableStorageClassLabels is a list of label keys set on the storage classes within the cluster which can be customized by the user. |
| `vsphereOptions.persistentVolumes.defaultStorageClass` | string |  |  | DefaultStorageClass sets the default storage class inside the cluster. |
| `vsphereOptions.persistentVolumes.defaultVolumeSnapshotClass` | string |  |  | DefaultVolumeSnapshotClass sets the default volume snapshot class inside the cluster. |

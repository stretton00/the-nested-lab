| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `wait` | object |  | e.g. `{fields: [{path: status.powerState, value: PoweredOn}], ...}` | resource yaml |
| `wait.fields` | array of object |  | e.g. `[{path: status.powerState, value: PoweredOn}]` | List of fields for whose value needs to be waited for resource to be finished |
| `wait.fields[].path` | string | yes | e.g. `status.powerState` | The path of the field within the Kubernetes resource |
| `wait.fields[].value` | string | yes | e.g. `PoweredOn` | The value that needs to be met for the wait to be finished. |
| `wait.fields[].indicatesFailure` | boolean |  | e.g. `true` | When the condition is met, indicates failure if set to true |
| `wait.conditions` | array of object |  | e.g. `[{type: VirtualMachineGuestNetworkConfigSynced, status: True}]` | List of conditions that indicate success/failure of resource |
| `wait.conditions[].type` | string | yes | e.g. `VirtualMachineGuestNetworkConfigSynced` | The condition type for which to wait |
| `wait.conditions[].reason` | string |  | e.g. `<condition reason>` | The condition reason for which to wait |
| `wait.conditions[].status` | string | yes | e.g. `True` | The value of the condition that needs to be met |
| `wait.conditions[].indicatesFailure` | boolean |  | e.g. `true` | When the condition is met, indicates failure if set to true |
| `wait.executionLogs` | object |  | e.g. `{failureMessagePattern: (?i)error, progressMessagePattern: (?i)creating}` | The message to fetch from the logs while the resource is being created. This is only supported for Kubernetes Jobs. |
| `wait.executionLogs.failureMessagePattern` | string |  | e.g. `(?i)error` | The message pattern to check for to fail the resource creation. If the message is found in the logs, the resource creation will be marked as failed. |
| `wait.executionLogs.progressMessagePattern` | string | yes | e.g. `(?i)creating` | The message pattern to check for to indicate that the resource creation is in progress. If the message is found in the logs, it will be shown as part of the deployment. |
| `wait.skipWaitOnDelete` | boolean |  | e.g. `true` | If false, do not wait for resources to be gone before completing |
| `count` | integer |  | default `1` | The number of resource instances to be created. |
| `context` | string | yes | e.g. `${resource.namespace.id}` | The CCI.Supervisor.Namespace resource id |
| `existing` | boolean |  | default `false` | Use existing supervisor namespace |
| `manifest` | object | yes | e.g. `{apiVersion: vmoperator.vmware.com/v1alpha5, kind: VirtualMachine, spec: ...}` | The yaml representation of the Kubernetes resource |

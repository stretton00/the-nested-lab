| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `count` | integer |  | default `1` | The number of resource instances to be created. |
| `privateIPs` | array of string |  | e.g. `[10.200.0.0/20]` | List of private IPs to be used in the VPC |
| `regionName` | string | yes | e.g. `f06` | Region name for the VPC |
| `generateName` | string | yes | e.g. `vpc-app` | Prefix for the generated name of the VPC |

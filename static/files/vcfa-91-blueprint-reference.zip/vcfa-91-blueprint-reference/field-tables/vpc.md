| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `count` | integer |  | default `1` | The number of resource instances to be created. |
| `privateIPs` | array of string |  |  | List of private IPs to be used in the VPC |
| `regionName` | string | yes |  | Region name for the VPC |
| `generateName` | string | yes |  | Prefix for the generated name of the VPC |

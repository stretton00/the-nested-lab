| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `name` | string |  | e.g. `team-a-dev` | Supervisor namespace name |
| `count` | integer |  | default `1` | The number of resource instances to be created. |
| `zones` | array of object |  | e.g. `[{name: domain-c9, cpuLimit: 4000M}]` | Zone overrides for the namespace |
| `zones[].name` | string | yes | e.g. `domain-c9` | Name of the zone |
| `zones[].cpuLimit` | string | yes | e.g. `4000M` | CPU limit in M or G |
| `zones[].memoryLimit` | string | yes | e.g. `8192Mi` | Memory limit in Mi, Gi, or Ti |
| `zones[].cpuReservation` | string | yes | e.g. `0M` | CPU reservation in M or G |
| `zones[].memoryReservation` | string | yes | e.g. `0Mi` | Memory reservation in Mi, Gi, or Ti |
| `segName` | string |  | e.g. `Default-Group` | Name of the Service Engine Group |
| `vpcName` | string |  | e.g. `vpc-student05` | Name of the vpc |
| `existing` | boolean |  | default `false` | Use existing supervisor namespace |
| `className` | string |  | e.g. `nested-pod` | Name of the supervisor namespace class |
| `vmClasses` | array of object |  | e.g. `[{name: best-effort-small}]` | VM Class overrides for the namespace |
| `vmClasses[].name` | string | yes | e.g. `best-effort-small` | Name of the vm class |
| `regionName` | string |  | e.g. `f06` | Name of the region |
| `description` | string |  | e.g. `Team sandbox` | Description of the supervisor namespace |
| `generateName` | string |  | e.g. `ns-demo` | Supervisor namespace generateName |
| `contentSources` | array of object |  | e.g. `[{name: my-library, type: ContentLibrary}]` | Content Source overrides for the namespace |
| `contentSources[].name` | string | yes | e.g. `my-library` | Name of the content source |
| `contentSources[].type` | string | yes | default `ContentLibrary` | Type of the content source |
| `storageClasses` | array of object |  | e.g. `[{name: vSAN Default Storage Policy, limit: 100Gi}]` | Storage Class overrides for the namespace |
| `storageClasses[].name` | string | yes | e.g. `vSAN Default Storage Policy` | Name of the storage class |
| `storageClasses[].limit` | string | yes | e.g. `100Gi` | Storage Class limit in Mi, Gi, or Ti |
| `infraPolicyNames` | array of string |  | e.g. `[<infrastructure policy>]` | Non-mandatory Infra Policy names |
| `sharedSubnetNames` | array of string |  | e.g. `[<shared subnet>]` | Name of subnets |

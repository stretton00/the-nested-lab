| Field | Type | Req. | Values | Description |
|---|---|---|---|---|
| `name` | string |  |  | Supervisor namespace name |
| `count` | integer |  | default `1` | The number of resource instances to be created. |
| `zones` | array of object |  |  | Zone overrides for the namespace |
| `zones[].name` | string | yes |  | Name of the zone |
| `zones[].cpuLimit` | string | yes |  | CPU limit in M or G |
| `zones[].memoryLimit` | string | yes |  | Memory limit in Mi, Gi, or Ti |
| `zones[].cpuReservation` | string | yes |  | CPU reservation in M or G |
| `zones[].memoryReservation` | string | yes |  | Memory reservation in Mi, Gi, or Ti |
| `segName` | string |  |  | Name of the Service Engine Group |
| `vpcName` | string |  |  | Name of the vpc |
| `existing` | boolean |  | default `false` | Use existing supervisor namespace |
| `className` | string |  |  | Name of the supervisor namespace class |
| `vmClasses` | array of object |  |  | VM Class overrides for the namespace |
| `vmClasses[].name` | string | yes |  | Name of the vm class |
| `regionName` | string |  |  | Name of the region |
| `description` | string |  |  | Description of the supervisor namespace |
| `generateName` | string |  |  | Supervisor namespace generateName |
| `contentSources` | array of object |  |  | Content Source overrides for the namespace |
| `contentSources[].name` | string | yes |  | Name of the content source |
| `contentSources[].type` | string | yes | default `ContentLibrary` | Type of the content source |
| `storageClasses` | array of object |  |  | Storage Class overrides for the namespace |
| `storageClasses[].name` | string | yes |  | Name of the storage class |
| `storageClasses[].limit` | string | yes |  | Storage Class limit in Mi, Gi, or Ti |
| `infraPolicyNames` | array of string |  |  | Non-mandatory Infra Policy names |
| `sharedSubnetNames` | array of string |  |  | Name of subnets |
